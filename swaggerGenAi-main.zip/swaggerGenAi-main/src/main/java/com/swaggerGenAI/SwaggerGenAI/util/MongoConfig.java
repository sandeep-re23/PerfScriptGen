package com.swaggerGenAI.SwaggerGenAI.util;


import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.config.AbstractMongoClientConfiguration;
import org.springframework.data.mongodb.core.SimpleMongoClientDbFactory;
import org.springframework.data.mongodb.MongoTransactionManager;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.convert.MappingMongoConverter;
import org.springframework.data.mongodb.core.mapping.MongoMappingContext;
import org.springframework.data.mongodb.gridfs.GridFsTemplate;

@Configuration
public class MongoConfig extends AbstractMongoClientConfiguration {

    @Value("${spring.data.mongodb.uri}")
    private String mongoUri;

    public String getCollectionName() {
        return collectionName;
    }

    public void setCollectionName(String collectionName) {
        this.collectionName = collectionName;
    }

    private String collectionName;


    @Bean
    public MongoClient mongoClient() {
        return MongoClients.create(mongoUri);
    }

    @Bean
    public MongoTemplate mongoTemplate() {
        return new MongoTemplate(mongoDbFactory());
    }

    @Bean
    public GridFsTemplate gridFsTemplate() {
        return new GridFsTemplate(mongoDbFactory(), mongoConverter(), "Scripts");
    }

    @Bean
    public GridFsTemplate gridFsTemplateApiScript() {
        return new GridFsTemplate(mongoDbFactory(), mongoConverter(), "APIScripts");
    }

    @Bean
    public GridFsTemplate gridFsTemplateFiles(){
        return new GridFsTemplate(mongoDbFactory(),mongoConverter(),"Files");
    }

    @Bean
    public MongoTransactionManager transactionManager() {
        return new MongoTransactionManager(mongoDbFactory());
    }

    @Bean
    public MappingMongoConverter mongoConverter() {
        return new MappingMongoConverter(mongoDbFactory(), new MongoMappingContext());
    }

    @Override
    protected String getDatabaseName() {
        return "neuro_dev";
    }


}
