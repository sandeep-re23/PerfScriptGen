package com.swaggerGenAI.SwaggerGenAI.exception;
public class ScriptGenerationExceptionHandler extends Exception {
    public ScriptGenerationExceptionHandler(String message) {
        super(message);
    }

}
