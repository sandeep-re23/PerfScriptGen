package com.swaggerGenAI.SwaggerGenAI.controller;


import com.swaggerGenAI.SwaggerGenAI.exception.ScriptGenerationExceptionHandler;
import com.swaggerGenAI.SwaggerGenAI.service.UserStoryToJmxService;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;

@RestController
@RequestMapping("/userStory")
public class UserStoryToJmxController {

    @Autowired
    UserStoryToJmxService userStoryToJmxService;


    @PostMapping("/createBDDJMX")
    public void createBDDJMX(@RequestParam("file1") MultipartFile file1, @RequestParam("projectName") String projectName, @RequestParam("userId") String userId, @RequestParam("type1") String type1, @RequestParam("file2") MultipartFile file2, @RequestParam("type2") String type2) throws Exception {
        JSONObject obj1 = userStoryToJmxService.uploadFile(file1,projectName,userId,type1);
        JSONObject obj2 = userStoryToJmxService.uploadFile(file2,projectName,userId,type2);
        String FileName1 = (String) obj1.get("fileName");
        String FileName2 = (String) obj2.get("fileName");
        userStoryToJmxService.download(FileName1);
        userStoryToJmxService.download(FileName2);
        String BDDfileName = userStoryToJmxService.writeToFile();

        System.out.println(BDDfileName);

    }

    @PostMapping("/upload")
    public JSONObject uploadFile(@RequestParam("file") MultipartFile file, @RequestParam("projectName") String projectName, @RequestParam("userId") String userId, @RequestParam("type") String type) throws ScriptGenerationExceptionHandler, ScriptGenerationExceptionHandler {
        return userStoryToJmxService.uploadFile(file,projectName,userId,type);
    }

    @GetMapping("/downloadScript")
    public ResponseEntity downloadGeneratedScript(@RequestParam("filename") String filename) throws ScriptGenerationExceptionHandler, IOException {
//        return scriptGenerationService.downloadGeneratedScript(jobId);
        return userStoryToJmxService.download(filename);
    }

    @GetMapping("/test")
    public ResponseEntity<?> test() throws Exception {
        ArrayList<ArrayList<String>> res =  userStoryToJmxService.readCsvToString("C:\\SwaggerGenAI\\src\\main\\\\resources\\UserStory.csv");
        return new ResponseEntity<>(res, HttpStatus.OK);
    }


    @GetMapping("/testSwagger")
    public ResponseEntity<String> testSwagger() throws Exception {
        String res =  userStoryToJmxService.readSwaggerJson("C:\\SwaggerGenAI\\src\\main\\resources\\swagger.json","/store/order/9889");
        return new ResponseEntity<>(res, HttpStatus.OK);
    }

    @GetMapping("/testpost")
    public  ResponseEntity<String> testpost(){
        String res = userStoryToJmxService.postmethodGetPayLoad("C:\\SwaggerGenAI\\src\\main\\resources\\swagger.json","/store/order");
        return new ResponseEntity<>(res,HttpStatus.OK);
    }

    @GetMapping("/writeToFile")
    public ResponseEntity<?> writeToFile() throws Exception{
        
        String res = userStoryToJmxService.writeToFile();
        return new ResponseEntity<>(res,HttpStatus.OK);
    }
}
