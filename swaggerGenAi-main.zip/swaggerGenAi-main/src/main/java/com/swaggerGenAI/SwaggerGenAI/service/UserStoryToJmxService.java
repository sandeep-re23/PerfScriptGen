package com.swaggerGenAI.SwaggerGenAI.service;


import com.google.gson.Gson;
import com.mongodb.client.gridfs.model.GridFSFile;
import com.swaggerGenAI.SwaggerGenAI.exception.ScriptGenerationException;
import com.swaggerGenAI.SwaggerGenAI.exception.ScriptGenerationExceptionHandler;
import com.swaggerGenAI.SwaggerGenAI.util.MongoConfig;
import io.swagger.models.*;
import io.swagger.models.parameters.Parameter;
import io.swagger.models.properties.StringProperty;
import org.apache.commons.io.IOUtils;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.gridfs.GridFsTemplate;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.time.LocalDateTime;
import io.swagger.parser.SwaggerParser;
import io.swagger.models.parameters.BodyParameter;
import io.swagger.models.properties.Property;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import io.swagger.models.properties.RefProperty;
import io.swagger.models.properties.ArrayProperty;
import org.springframework.web.multipart.MultipartFile;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;




@Service
public class UserStoryToJmxService {

    @Autowired
    private MongoConfig mongoConfig;


//    public static String writing(Map<String,Object> values) throws IOException {
//        File swaggerFile = new File("swagger.txt");
//        if(swaggerFile.createNewFile()){
//            System.out.println("File Created : "+ swaggerFile.getName());
//        }else {
//            System.out.println("File already exists ");
//        }
//        FileWriter myWriter = new FileWriter("swagger.txt");
//        myWriter.write("Feature:"+ values.getName +"\n" +
//                "\n" +
//                "\tScenario 1 :Succesfully Create a new user using post request\n" +
//                "\t\tGiven I have a valid user payload in <payload_file>\n" +
//                "\t\tAnd Set the header as <hearder1Key> as <header1Value> \t\n" +
//                "\t\tWhen I make a Post request on the user_endpoint with the payload\n" +
//                "\t\tIf the email-id is already present in the database.\n" +
//                "\t\tThen the response body will contain \"\"Already user present with email \"<Email>\"\n" +
//                "\t\tElse if Email ID already not present\n" +
//                "\t\tThen I should get a response status code of <status_code>\n" +
//                "\t\tAnd the response body contain the text \"User Registered\"\n" +
//                "\t\tExample :\n" +
//                "\t\t\t| payload_file | header1Key | header1Key | status_code | Response Body | Email |\n" +
//                "\t\t\t| Register_user.json | \"Content-Type\" | \"application/json\" | 200 | User Registered | user@gmail.com |\n" +
//                "\t\t\t| sample_name.json | \"Content-Type\" | \"application/json\" | 200 | Already user present with email sample@gmail.com | sample@gmail.com |");
//    }

    public JSONObject uploadFile(MultipartFile file, String projectName, String userId, String type) throws ScriptGenerationException, ScriptGenerationExceptionHandler {
        try {
            System.out.println("file type - " + file.getOriginalFilename() + " ");
            String fileExtension = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf("."));
            String filename = type + "_" + projectName + "_" + userId + fileExtension; // Give a random filename here.
            byte[] bytes = file.getBytes();
            String insPath = "./" + filename; // Directory path where you want to save ;
            Files.write(Paths.get(insPath), bytes);
            System.out.println("File uploaded successfully " + filename);
            CloseableHttpClient httpClient = HttpClients.createDefault();
            HttpPost uploadFile = new HttpPost("http://10.120.101.34:8000/uploadfile");
            MultipartEntityBuilder builder = MultipartEntityBuilder.create();
            // This attaches the file to the POST:
            File f = new File("./" + filename);
            builder.addBinaryBody(
                    "file",
                    new FileInputStream(f),
                    ContentType.parse(file.getContentType()),
                    f.getName()
            );
            HttpEntity multipart = builder.build();
            uploadFile.setEntity(multipart);
            CloseableHttpResponse response = httpClient.execute(uploadFile);
            HttpEntity responseEntity = response.getEntity();
//            responseEntity.getContent();
            Files.delete(Paths.get(insPath));
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("message", "File uploaded successfully");
            jsonObject.put("fileName", filename);

            return jsonObject;

        } catch (Exception e) {
            e.printStackTrace();
            throw new ScriptGenerationExceptionHandler(e.getMessage());
        }

    }


    public ResponseEntity download(String fileName) throws IOException {
        GridFsTemplate gridFsTemplate = null;
        gridFsTemplate =mongoConfig.gridFsTemplateFiles();
        InputStream inputStream = null;
        ByteArrayOutputStream baos = null;
        try {
            GridFSFile files = gridFsTemplate.findOne(new Query(Criteria.where("filename").is(fileName)));
//            System.out.println(files);
            inputStream = gridFsTemplate.getResource(files).getInputStream();

            baos = new ByteArrayOutputStream();


            byte[] bytes = new byte[1024];
            int length;
            while ((length = inputStream.read(bytes)) >= 0) {
                baos.write(bytes, 0, length);
            }


            byte[] savebytes = baos.toByteArray();

            // Specify the path of the file where you want to save it
            String filePath = "./src/main/resources/UserStory.csv";
            if(fileName.contains(".json")){
                filePath = "./src/main/resources/swagger.json";
            }
            // Write the byte array to the file.
            Files.write(Paths.get(filePath), savebytes);
            System.out.println("File saved successfully");

        }catch (IOException e){
            System.out.println("Error occurred while saving file");
            e.printStackTrace();
        }
        catch (Exception e) {
            throw new RuntimeException("Failed to add file to zip", e);
        }
        finally {
            if (inputStream != null) {
                inputStream.close();
            }
            if (baos != null) {
                baos.close();
            }

        }
        HttpHeaders headers = new HttpHeaders();
        headers.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + fileName + ".zip");
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
//

        return new ResponseEntity<>(baos.toByteArray(), headers, HttpStatus.OK);
//            return new ResponseEntity<>(HttpStatus.OK);

    }

    public static String writeToFile() throws Exception {
        String csvFile = "./src/main/resources/UserStory.csv";
        String swaggerFile = "./src/main/resources/swagger.json";
        ArrayList<ArrayList<String>> valuesList = readCsvToString(csvFile);
        File swagger = new File("swagger.txt");
        if (swagger.createNewFile()) {
            System.out.println("File Created : " + swagger.getName());
        } else {
            System.out.println("File already exists ");
        }
        FileWriter myWriter = new FileWriter("swagger.txt");
        myWriter.write("Feature: PetStore \n");
        myWriter.write("\n");

        myWriter.write("\tScenario 1 : (Store Order)\n");
        String payLoad = "";
        String postEndPoint = "";
        String getEndPoint = "";
        String postStatusCode = "";
        String getStatusCode = "";
        StringBuilder sb = new StringBuilder();
        Map<String, Object> map = new HashMap<>();
        ArrayList<ArrayList<String>> postmap = new ArrayList<>();
        ArrayList<ArrayList<String>> getmap = new ArrayList<>();
        int scenarioCount = 1;
        for (int i = 1; i < valuesList.size(); i++) {
            if(valuesList.get(i).size() == 0 || valuesList.get(i).get(0).toLowerCase().equals("end")){
                printHelper(myWriter,sb,postmap,getmap);
                postmap = new ArrayList<>();
                getmap = new ArrayList<>();
                sb = new StringBuilder();
                scenarioCount++;
                if(valuesList.get(i).size() == 0){
                    myWriter.write("\n\n\tScenario "+scenarioCount +"  : (Store Order)\n");
                }

                continue;
            }
            ArrayList<String> currentMap = new ArrayList<>();
            String endpoint = valuesList.get(i).get(0);
            System.out.println("endpoint :" + i + " " + endpoint);
            String method = valuesList.get(i).get(1);
            System.out.println("method :" + i + " " + method);
            String assertion = valuesList.get(i).get(2);
            System.out.println("assertion :" + i + " " + assertion);
            String assertionValue = valuesList.get(i).get(3);
            String[] assertionValueArr = new String[]{};
            if(assertion.toLowerCase().equals("true")){
                 assertionValueArr = assertionValue.split(":");
                System.out.println("assertionValue :" + i + " " + assertionValueArr);
            }

            String substitution = valuesList.get(i).get(4);
            System.out.println("substitution :" + i + " " + substitution);


            if (method.toLowerCase().equals("post")) {

                payLoad = postmethodGetPayLoad(swaggerFile, endpoint);
                postEndPoint = endpoint;
                ArrayList<String> resCode = getResponseCode(swaggerFile, endpoint, method);
                System.out.println(resCode.get(0));
                postStatusCode = resCode.get(0);

                sb.append("\t\tPOST\n");
                if (assertion.toLowerCase().equals("true")) {
                    sb.append("\t\tuse JSON extractor to extract ");
                    for (int j = 0; j < assertionValueArr.length; j++) {
                        sb.append("\"" + assertionValueArr[j] + "\",");
                    }
                    sb.append("\n");
                }

                currentMap.add(payLoad);
                currentMap.add(endpoint);
                currentMap.add(postStatusCode);
                postmap.add(currentMap);
                currentMap = new ArrayList<>();
            } else if (method.toLowerCase().equals("get")) {
                getEndPoint = endpoint;
                currentMap.add(getEndPoint);
                if (!substitution.toLowerCase().equals("null")) {
                    endpoint = endpoint + "/{" + substitution + "}";
                    sb.append("\t\tmake a GET request to the endpoint <get_endpoint>+\"" + substitution + "\"   \n");
                } else {
                    sb.append("\t\tGET\n");
                }
                ArrayList<String> resCode = getResponseCode(swaggerFile, endpoint, method);
                getStatusCode = resCode.get(0);
                currentMap.add(getStatusCode);
                getmap.add(currentMap);
                currentMap = new ArrayList<>();
                System.out.println(resCode);
            }

//            } else if (method.toLowerCase().equals("put")) {
//                String resCode = getResponseCode(swaggerFile,endpoint,method);
//                System.out.println(resCode);
//            }else if(method.toLowerCase().equals("delete")){
//                String resCode = getResponseCode(swaggerFile,endpoint,method);
//                System.out.println(resCode);
//            }
//            myWriter.write("\n"+sb+"\n");
//            sb = new StringBuilder();
        }
        myWriter.close();

        int randomId = (int)Math.ceil(Math.random()*1000);

        UserStoryToJmxService userStoryToJmxService = new UserStoryToJmxService();


        MultipartFile mulipartfileSwagger = convertFileToMultipartFile(swagger);

        userStoryToJmxService.uploadFile(mulipartfileSwagger,"swaggerBDDGenAiOutput", String.valueOf(randomId),"txt");

//        myWriter.write("\n" + sb + "\n" +
//                "\t\t\t| payload_file | post_endpoint | post_status_code | get_endpoint | get_status_code|\n"
//        );
//        int size = Math.max(postmap.size(), getmap.size());
//        int i = 0;
//        while (i < size) {
//            if ((i <= postmap.size() - 1) && (i <= getmap.size() - 1)) {
//
//                ArrayList<String> postlist = postmap.get(i);
//                ArrayList<String> getlist = getmap.get(i);
//                myWriter.write(
//                        "\t\t\t| " + postlist.get(0) + " | " + "\"" + postlist.get(1) + "\" | " + "\"" + postlist.get(2) + "\"" + " | " + "\"" + getlist.get(0) + "\"" + " | \"" + getlist.get(1) + "\"" + "|\n"
//                );
//
//            }else if((i <= postmap.size() - 1) && (i >= getmap.size())){
//                ArrayList<String> postlist = postmap.get(i);
////                ArrayList<String> getlist = getmap.get(i);
//                myWriter.write(
//                        "\t\t\t| " + postlist.get(0) + " | " + "\"" + postlist.get(1) + "\" | " + "\"" + postlist.get(2) + "\"" + " | " + "" + "     " + "" + " | " + "       " + "" + "|\n"
//
//                );
//
//            }else if((i >= postmap.size() ) && (i <= getmap.size()-1)){
////                ArrayList<String> postlist = postmap.get(i);
//                ArrayList<String> getlist = getmap.get(i);
//                myWriter.write(
//                        "\t\t\t| "+      " | " + "" +     " | " + ""     + "" + " | " + "\"" + getlist.get(0) + "\"" + " | \"" + getlist.get(1) + "\"" + "|\n"
//
//                );
//
//            }
//            i++;
//            System.out.println(sb);
//        }

        return "file written";
    }

    public static MultipartFile convertFileToMultipartFile(File file) throws IOException {
        FileInputStream input = new FileInputStream(file);
        MultipartFile multipartFile = new MockMultipartFile("file",
                file.getName(), "text/plain", IOUtils.toByteArray(input));
        input.close();
        return multipartFile;
    }

    public static void printHelper(FileWriter myWriter,StringBuilder sb,ArrayList<ArrayList<String>> postmap,ArrayList<ArrayList<String>> getmap) throws IOException {
        System.out.println("stringBuuilder:----------------------->"+sb+"<----------------------------------");
        myWriter.write("\n" + sb + "\n" +
                "\t\t\t| payload_file | post_endpoint | post_status_code | get_endpoint | get_status_code|\n"
        );
        int size = Math.max(postmap.size(), getmap.size());
        int i = 0;
        while (i < size) {
            if ((i <= postmap.size() - 1) && (i <= getmap.size() - 1)) {

                ArrayList<String> postlist = postmap.get(i);
                ArrayList<String> getlist = getmap.get(i);
                myWriter.write(
                        "\t\t\t| " + postlist.get(0) + " | " + "\"" + postlist.get(1) + "\" | " + "\"" + postlist.get(2) + "\"" + " | " + "\"" + getlist.get(0) + "\"" + " | \"" + getlist.get(1) + "\"" + "|\n"
                );

            }else if((i <= postmap.size() - 1) && (i >= getmap.size())){
                ArrayList<String> postlist = postmap.get(i);
//                ArrayList<String> getlist = getmap.get(i);
                myWriter.write(
                        "\t\t\t| " + postlist.get(0) + " | " + "\"" + postlist.get(1) + "\" | " + "\"" + postlist.get(2) + "\"" + " | " + "" + "     " + "" + " | " + "       " + "" + "|\n"

                );

            }else if((i >= postmap.size() ) && (i <= getmap.size()-1)){
//                ArrayList<String> postlist = postmap.get(i);
                ArrayList<String> getlist = getmap.get(i);
                myWriter.write(
                        "\t\t\t| "+      " | " + "" +     " | " + ""     + "" + " | " + "\"" + getlist.get(0) + "\"" + " | \"" + getlist.get(1) + "\"" + "|\n"

                );

            }
            i++;
//            System.out.println(sb);
        }
    }


    public static ArrayList<ArrayList<String>> readCsvToString(String file) throws Exception {
        Scanner sc = new Scanner(new File(file));
        ArrayList<ArrayList<String>> lines = new ArrayList<>();
        while(sc.hasNextLine()){
            String[] line = sc.nextLine().split(",");
            ArrayList<String> lineList = new ArrayList<>(Arrays.asList(line));
            lines.add(lineList);
        }
        sc.close();
        System.out.println(lines);
        return lines;
    }
    public static ArrayList<String> getResponseCode(String file, String endpoint, String method){
        Swagger swagger = new SwaggerParser().read(file);
        method = method.toLowerCase();
        Path path = swagger.getPath(endpoint);
        Operation response = null;
        if(method.equals("post")){
            response = path.getPost();
        }else if(method.equals("get")){
            response = path.getGet();
        } else if (method.equals("delete")) {
            response = path.getDelete();
        }else{
            response = path.getPut();
        }

        ArrayList<String> responseCodes = new ArrayList<>();
        Map<String, Response> res = response.getResponses();
        for(Map.Entry<String,Response> entry : res.entrySet()){
            responseCodes.add(entry.getKey());
        }
        return responseCodes;
    }
    public static String postmethodGetPayLoad(String file, String endpoint ) {
        Swagger swagger = new SwaggerParser().read(file);
        Path path = swagger.getPath(endpoint);
        Operation post = path.getPost();
        String jsonString = "";
        for (Parameter parameter : post.getParameters()) {
            if (parameter instanceof BodyParameter) {
                BodyParameter bodyParameter = (BodyParameter) parameter;
                Model model = bodyParameter.getSchema();
                // Check if the model is a reference model
                if (model instanceof RefModel) {
                    RefModel refModel = (RefModel) model;
                    // Look up the referenced model in the definitions
                    model = swagger.getDefinitions().get(refModel.getSimpleRef());
                }
                // Now you can access the model of the POST request
                // Let's print it
                Map<String, Property> properties = model.getProperties();
                Map<String,String> modelMap = new HashMap<>();
                for (Map.Entry<String, Property> entry : properties.entrySet()) {
//                    System.out.println("example :"+entry.getValue().getExample());
//                    System.out.println("format :"+ entry.getValue().getFormat());
//                    System.out.println("empty value :"+entry.getValue().getAllowEmptyValue());

//                    System.out.println("Property name: " + entry.getKey());
//                    System.out.println("Property type: " + entry.getValue().getType());

                    if (entry.getValue() instanceof StringProperty) {
//                        System.out.println("true");
                        StringProperty stringProperty = (StringProperty) entry.getValue();
                        List<String> enumValues = stringProperty.getEnum();
                        if (enumValues != null) {
//                            System.out.println("Enum values: " + enumValues);
                            modelMap.put(entry.getKey(),enumValues.get(0));
                        }
                    } else if (entry.getValue().getType().equals("ref")) {
                        System.out.println("yes this is correct");
                    } else {
                        if(entry.getValue().getType().equals("integer")){
                            modelMap.put(entry.getKey(),"0");
                        }
                        else{
                            if(entry.getValue().getType().equals("boolean")){
                                modelMap.put(entry.getKey(),"true");
                            } else if (entry.getValue().getType().equals("array")) {
                                modelMap.put(entry.getKey(),"[enter your values]");
                            } else if (entry.getValue().getFormat().equals("date-time")){
                                LocalDateTime currentDateTime = LocalDateTime.now();
                                modelMap.put(entry.getKey(), String.valueOf(currentDateTime));
                            }else{
                                modelMap.put(entry.getKey(),entry.getValue().getType());
                            }
                        }
                    }
                }
                Gson gson = new Gson();

                // Convert the map to a JSON string
                jsonString = gson.toJson(modelMap);
//                System.out.println(jsonString);
            }
        }
        return jsonString;
    }
    public static String readSwaggerJson(String file,String endpoint){
        Swagger swagger = new SwaggerParser().read(file);
        // replace with your endpoint

        Path path = swagger.getPath(endpoint);
        if (path != null) {
            Operation operation = path.getGet(); // Change this based on the HTTP method
            if (operation != null) {
                // Read the payload
                for (Parameter parameter : operation.getParameters()) {
                    if (parameter instanceof BodyParameter) {
                        BodyParameter bodyParameter = (BodyParameter) parameter;
                        System.out.println("Parameter Name: " + bodyParameter.getName());
                        System.out.println("Parameter Description: " + bodyParameter.getDescription());

                        // Get the schema
                        String ref = bodyParameter.getSchema().getReference();
                        if (ref != null) {
                            // Remove the '#/definitions/' prefix
                            String definitionName = ref.replace("#/definitions/", "");
                            Model model = swagger.getDefinitions().get(definitionName);
                            System.out.println("Parameter Schema: " + model);
                        }
                    }
                }

                // Read the response codes
                for (String responseCode : operation.getResponses().keySet()) {
                    Response response = operation.getResponses().get(responseCode);
                    System.out.println("Response Code: " + responseCode);
                    System.out.println("Response Description: " + response.getDescription());
                }
            }
        }
        return "read swagger json file";
    }




//    public static String postmethodGetResponsePayLoad(String file, String endpoint ) {
//        Swagger swagger = new SwaggerParser().read(file);
//        Path path = swagger.getPath(endpoint);
//        Operation post = path.getPost();
//        String jsonString = "";
//        for (Response response : post.getResponses()) {
//            if (parameter instanceof BodyParameter) {
//                BodyParameter bodyParameter = (BodyParameter) parameter;
//                Model model = bodyParameter.getSchema();
//                // Check if the model is a reference model
//                if (model instanceof RefModel) {
//                    RefModel refModel = (RefModel) model;
//                    // Look up the referenced model in the definitions
//                    model = swagger.getDefinitions().get(refModel.getSimpleRef());
//                }
//                // Now you can access the model of the POST request
//                // Let's print it
//                Map<String, Property> properties = model.getProperties();
//                Map<String,String> modelMap = new HashMap<>();
//                for (Map.Entry<String, Property> entry : properties.entrySet()) {
////                    System.out.println("example :"+entry.getValue().getExample());
////                    System.out.println("format :"+ entry.getValue().getFormat());
////                    System.out.println("empty value :"+entry.getValue().getAllowEmptyValue());
//
////                    System.out.println("Property name: " + entry.getKey());
////                    System.out.println("Property type: " + entry.getValue().getType());
//                    if (entry.getValue() instanceof StringProperty) {
////                        System.out.println("true");
//                        StringProperty stringProperty = (StringProperty) entry.getValue();
//                        List<String> enumValues = stringProperty.getEnum();
//                        if (enumValues != null) {
////                            System.out.println("Enum values: " + enumValues);
//                            modelMap.put(entry.getKey(),enumValues.get(0));
//                        }
//                    }else {
//                        if(entry.getValue().getType().equals("integer")){
//                            modelMap.put(entry.getKey(),"0");
//                        }
//                        else{
//                            if(entry.getValue().getType().equals("boolean")){
//                                modelMap.put(entry.getKey(),"true");
//                            }else if (entry.getValue().getFormat().equals("date-time")){
//                                LocalDateTime currentDateTime = LocalDateTime.now();
//                                modelMap.put(entry.getKey(), String.valueOf(currentDateTime));
//                            }else{
//                                modelMap.put(entry.getKey(),entry.getValue().getType());
//                            }
//                        }
//                    }
//                }
//                Gson gson = new Gson();
//
//                // Convert the map to a JSON string
//                jsonString = gson.toJson(modelMap);
////                System.out.println(jsonString);
//            }
//        }
//        return jsonString;
//    }





//    public static String postMethod2(String file, String endPoint) throws Exception {
//
//        String swaggerFileLocation = file;
//        String endpoint = endPoint;         // Read the Swagger JSON from the file
//        File swaggerFile = new File(swaggerFileLocation);
//        FileReader reader = new FileReader(swaggerFile);
//        ObjectMapper mapper = new ObjectMapper();
//        JsonNode rootNode = mapper.readValue(reader, JsonNode.class);
//
//        // Get the "post" node for the "/store/order" operation
//        JsonNode endpointNode = rootNode.path(endpoint);
//        if (endpointNode.isMissingNode()) {
//            throw new Exception("Endpoint not found: " + endpoint);
//        }
//        // Extract and process schemas
//        JsonNode operationNode = endpointNode.path(getHttpMethod(endpointNode));
//        // Assuming a single HTTP method per endpoint
//        JsonNode orderSchema = getSchemaFromRef(operationNode.path("parameters").get(0).path("schema"));
//        JsonNode responseSchema = getSchemaFromRef(operationNode.path("responses").path("200").path("schema"));
//        // Print the retrieved schemas (optional)
//        System.out.println("Order Schema:");
//        System.out.println(orderSchema.toString());
//        System.out.println("Response Schema:");
//        System.out.println(responseSchema.toString());
//
//
//        return "";
//    }
//    private static String getHttpMethod(JsonNode endpointNode) {
////        for (Iterator<String> it = endpointNode.fieldNames(); it.hasNext(); ) {
////            String key = it.next();
////            if (key.equals("get") || key.equals("post") || key.equals("put") || key.equals("delete") || key.equals("patch")) {
////                return "post";
////            }
////        }
//        return "post";
////        throw new IllegalArgumentException("Unsupported HTTP method for endpoint: " + endpointNode);
//    }
//
//    private static JsonNode getSchemaFromRef(JsonNode schemaNode) throws Exception {
//        if (schemaNode.has("$ref")) {
//            String refPath = schemaNode.get("$ref").asText();
//            return resolveReference(refPath);
//        } else {
//            return schemaNode;
//        }
//    }
//
//    private static JsonNode resolveReference(String refPath) throws Exception {
//        ObjectMapper mapper = new ObjectMapper();
//        JsonNode rootNode = mapper.readValue(getSwaggerJson(), JsonNode.class); // Replace with logic to access your full Swagger JSON
//
//        String[] pathSegments = refPath.substring(2).split("/"); // Skip "#/"
//
//        JsonNode currentNode = rootNode;
//        for (String segment : pathSegments) {
//            if (currentNode.isObject()) {
//                currentNode = ((ObjectNode) currentNode).get(segment);
//            } else {
//                throw new Exception("Invalid schema reference path: " + refPath);
//            }
//        }
//
//        return currentNode;
//    }
//
//    // Replace this method with your logic to access the full Swagger JSON content
//    private static String getSwaggerJson() {
//        // ... your implementation to retrieve the complete Swagger JSON
//        return null;
//    }
}



