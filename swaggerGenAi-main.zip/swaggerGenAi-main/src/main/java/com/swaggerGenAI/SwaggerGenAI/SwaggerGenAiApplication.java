package com.swaggerGenAI.SwaggerGenAI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SwaggerGenAiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SwaggerGenAiApplication.class, args);
	}

}
