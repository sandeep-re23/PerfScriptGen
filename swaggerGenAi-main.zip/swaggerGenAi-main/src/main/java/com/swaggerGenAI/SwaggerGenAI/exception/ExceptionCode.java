package com.swaggerGenAI.SwaggerGenAI.exception;


public enum ExceptionCode {
    DUPLICATE_RECORD(10001),
    CONFIG_NOT_FOUND(10002),
    INTERNAL_SERVER_ERROR(10005),
    INVALID_CONFIG(10004);


    private final int errorCode;

    private ExceptionCode(Integer errorCode) {
        this.errorCode = errorCode;
    }

}