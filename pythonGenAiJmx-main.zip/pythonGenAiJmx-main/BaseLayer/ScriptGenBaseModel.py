from typing import List, Dict, Union

from pydantic import BaseModel

class ScriptJmeter(BaseModel):
    fileName: str
    isCRAFT: bool
    isPageObjectModel: bool
    isPageFactoryModel: bool
    isBDD: bool
    isModular: bool
    isHybrid: bool
    isKeywordDriven: bool
    isDataDriven: bool
    isTestNG: bool
    isJUnit: bool
    isExtentReport: bool
    isCucumberReport: bool
    isAllureReport: bool
    useCaseName: str
    executedBy: str
    projectID: str
    language: str

class ScriptGen(BaseModel):
    fileName: str
    isCRAFT: bool
    isPageObjectModel: bool
    isPageFactoryModel: bool
    isBDD: bool
    isModular: bool
    isHybrid: bool
    isKeywordDriven: bool
    isDataDriven: bool
    isTestNG: bool
    isJUnit: bool
    isExtentReport: bool
    isCucumberReport: bool
    isAllureReport: bool
    useCaseName: str
    executedBy: str
    projectID: str
    language: str
    locatorPriority: list

class ScriptGenNoCrawl(BaseModel):
    xpathDetails: List[Dict[str, Union[str, int]]]
    isCRAFT: bool
    isPageObjectModel: bool
    isPageFactoryModel: bool
    isBDD: bool
    isModular: bool
    isHybrid: bool
    isKeywordDriven: bool
    isDataDriven: bool
    isTestNG: bool
    isJUnit: bool
    isMaven: bool
    isExtentReport: bool
    isCucumberReport: bool
    isAllureReport: bool
    isDefaultReport: bool
    useCaseName: str
    executedBy: str
    language: str
