from SwaggerPreprocessing import read_feature_file, read_jmx
from CraftAzureConnectJMXOG import CraftAsureConnectJMX
import re
 
 
def read_and_categorize_file():
    example_feature_file_path = r"Input\customer_service-Copy.feature"
    example_json1 = r"Input\Register_user.json"
    example_json2 = r"Input\user_name.json"
    example_json3 = r"Input\newProduct.json"
    example_feature_file, scenarios = read_feature_file(example_feature_file_path,
                                                        [example_json1, example_json2,example_json3])
 
    jmx = r"Input\Final_gen.jmx"
    jmx_file = read_jmx(jmx)
 
    # feature_file_path = r"Input\customer_service.feature"
    # json1 = r"Input\Register_user.json"
    # json2 = r"Input\user_name.json"
    # json3 = r"Input\newProduct.json"
    # feature_file, scenarios1 = read_feature_file(feature_file_path, [json1,json2,json3])

    feature_file_path = r"Input\petStore - Copy.feature"
    json1 = r"Input\pet_Register_user.json"
    json2 = r"Input\petProduct.json"
    # json3 = r"Input\newProduct.json"
    feature_file, scenarios1 = read_feature_file(feature_file_path, [json1, json2])
 
    feature_string = feature_file
    post_pattern = re.compile(r'\bPOST\b')
    get_pattern = re.compile(r'\bGET\b')
    post_matches = post_pattern.findall(feature_string)
    get_matches = get_pattern.findall(feature_string)
    post_count = len(post_matches)
    get_count = len(get_matches)
    total_count_feature = post_count + get_count
    print(total_count_feature)
    print(feature_file)
    jmx_file_output = CraftAsureConnectJMX.code_generation(CraftAsureConnectJMX, example_feature_file, jmx_file,
                                                           feature_file)
 
    get_pattern_jmx = re.compile(r'>GET<')
    post_pattern_jmx = re.compile(r'>POST<')
    get_matches_jmx = get_pattern_jmx.findall(jmx_file_output)
    post_matches_jmx = post_pattern_jmx.findall(jmx_file_output)
    total_count_jmx = len(get_matches_jmx) + len(post_matches_jmx)
 
    print(total_count_jmx)
 
    while not (total_count_feature == total_count_jmx):
        jmx_file_output = CraftAsureConnectJMX.code_generation_iterative(CraftAsureConnectJMX, example_feature_file,
                                                                         jmx_file,
                                                                         feature_file, jmx_file_output)
        get_matches_jmx = get_pattern_jmx.findall(jmx_file_output)
        post_matches_jmx = post_pattern_jmx.findall(jmx_file_output)
        total_count_jmx = len(get_matches_jmx) + len(post_matches_jmx)
        print(total_count_feature)
        print(total_count_jmx)
 
 
if __name__ == "__main__":
    read_and_categorize_file()