SELE_JAVA = "../CoreLogicLayer/IntelligentAutomation/FunctionalTestAutomation/SeleniumJava"
SELE_JAVA_TEST_NG = "../CoreLogicLayer/IntelligentAutomation/FunctionalTestAutomation/SeleniumJavaTestNG"
SELE_PYTHON = "../CoreLogicLayer/IntelligentAutomation/FunctionalTestAutomation/SeleniumPython"
KARATE_FRAMEWORK = "../CoreLogicLayer/IntelligentAutomation/FunctionalTestAutomation/KarateFrameworkPython"
ROBOT_FRAMEWORK = "../CoreLogicLayer/IntelligentAutomation/FunctionalTestAutomation/RobotFrameworkPython"

SELE_JAVA_SCRIPTS_FOLDER = '../CoreLogicLayer/IntelligentAutomation/FunctionalTestAutomation/SeleniumJava/data/FrameworkScripts/ScriptsFolder'
SELE_JAVA_FRAMEWORK_FOLDER = "../CoreLogicLayer/IntelligentAutomation/FunctionalTestAutomation/SeleniumJava/data/FrameworkScripts/FrameworkFolder"

CYPRESS_WEB_TS ="../CoreLogicLayer/IntelligentAutomation/FunctionalTestAutomation/CypressWebTs"
CYPRESS_WEB_TS_Data = "../CoreLogicLayer/IntelligentAutomation/FunctionalTestAutomation/CypressWebTs/data"
PLAYWRIGHT_JAVASCRIPT = "../CoreLogicLayer/IntelligentAutomation/FunctionalTestAutomation/PlaywrightJavascript"