import os
import shutil

class EmptyDirectory:

    def __init__(self):
        pass

    def remove(self, folder_path):
        # Check if the folder exists
        if os.path.exists(folder_path):
            # Iterate over the items in the folder
            for item in os.listdir(folder_path):
                item_path = os.path.join(folder_path, item)
                if os.path.isfile(item_path):
                    # If it's a file, delete it
                    os.remove(item_path)
                elif os.path.isdir(item_path):
                    # If it's a directory, delete it along with its contents
                    shutil.rmtree(item_path)