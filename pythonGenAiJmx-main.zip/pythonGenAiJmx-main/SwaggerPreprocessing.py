import csv
import json
import os
import re
import xml.etree.ElementTree as ET
 
 
def read_feature_file(filepath, json_path):
    with open(filepath, 'r') as feature_file:
        feature_content = feature_file.read()
        feature_content = str(feature_content)
 
    for i in json_path:
        with open(i, "r") as user_name_file:
            user_name_content = user_name_file.read()
 
        feature_content = feature_content.replace(os.path.basename(i), user_name_content)
 
    feature_string = str(feature_content)
    scenarios = re.findall(r'Scenario', feature_string)
 
    return feature_string, scenarios
 
 
def read_jmx(jmx_file_path):
    tree = ET.parse(jmx_file_path)
    root = tree.getroot()
 
    jmx_string = ET.tostring(root, encoding='utf8', method='xml').decode()
 
    return jmx_string
 