from langchain.chat_models import AzureChatOpenAI
from langchain.prompts.prompt import PromptTemplate
from langchain import LLMChain

 
class CraftAsureConnectJMXOG:
 
    def __init__(self):
        self.OPENAI_API_TYPE = "azure"
        self.OPENAI_API_VERSION = "2023-03-15-preview"
        self.OPENAI_API_BASE = "https://exploregenaiworkspace.openai.azure.com"
        self.OPENAI_API_KEY = "0b1d7d099829418fb1293b97f2ae9c23"
 
    def code_generation(self, data, jmx, feature):
        template_header_class = '''
                    As a Test Engineer you have to write JMX file content from a feature file
                    ->I am giving you a example feature file
                    {data}
                    *Below is the example of how a JMX looks like for the example feature file*
                    {jmx}
                    The way this example JMX has been written by carefully analyzing the example feature file, STRICTLY following the same path, write the COMPLETE JMX file content for the below feature file
                    {feature}
                    Ensure:
                    1. Make sure write host, port, testData with file name as user_data.csv and in "<Arguments>" tag
                    2. Write all other possible arguments in "<Arguments>" tags by analyzing the feature file
                    3. Write JMX flow for all scenarios with their all respective POST, GET calls mentioned in feature file
                    4. COMPULSORILY Add "<thread group>","<transaction controller>", "<ConfigTestElement>" tags in JMX content
                    5. ALSO DON'T FORGET TO ADD "<CSVDataSet>" tag with file name as "testData.csv"
                    6. In the path of each Request STRICTLY add the post_endpoint value not the post_endpoint variable 
                    7. STRICTLY Use Json value from Example in the feature file inside JMX file
                    8. In the Body Data of the Post request STRICTLY add the payload_file Json not the variable name
                    9. For each validation value there should be different "<responseAssertion>" tag with relevant "Assertion.test_field"
                    10. Inside the Response Assertion inside Patterns to Test field pass the status_code value not the variable name
                    11. STRICTLY include 'View Results Tree' at the end of the JMX file content
                    In the example feature file and example JMX for that, all possible different type of scenarios are there,
                    make sure to include ONLY RELEVANT type of scenarios while writing JMX content which are mentioned in input feature file.
                    STRICTLY DO NOT TRUNCATE THE CODE GENERATION IN BETWEEN WRITE FULL CODE
                    '''
 
        prompt_header = PromptTemplate(
            input_variables=["data", "jmx", "feature"], template=template_header_class)
 
       
 
        qa_prompt_header = LLMChain(
            llm=AzureChatOpenAI(deployment_name="gpt35exploration", model_name="gpt-35-turbo", temperature=0.1,
                                openai_api_key="0b1d7d099829418fb1293b97f2ae9c23",
                                openai_api_base="https://exploregenaiworkspace.openai.azure.com",
                                openai_api_version="2023-03-15-preview"),
            prompt=prompt_header)
 
        output_qa_prompt_header = qa_prompt_header.run(
            {'data': data,
             'jmx': jmx,
             'feature': feature
             })
        out_path_c = r"jmeterapitest_old.jmx"
        with open(out_path_c, "w") as file:
            file.write(output_qa_prompt_header)
 
        return output_qa_prompt_header
 
    def code_generation_iterative(self, data, jmx, feature, generated_jmx):
        template_header_class = '''
                    As a Test Engineer you have to write JMX file content from a feature file
                    ->I am giving you a example feature file
                    {data}
                    *Below is the example of how a JMX looks like for the example feature file*
                    {jmx}
                    The way this example JMX has been written by carefully analyzing the example feature file, STRICTLY following the same path, write the COMPLETE JMX file content for the below second feature file
                    {feature}
                    This is the INCOMPLETE generated JMX code for second feature file COMPLETE this
                    {generated_jmx}
                    Ensure:
                    1. Make sure write host, port, testData with file name as user_data.csv and in "<Arguments>" tag
                    2. Write all other possible arguments in "<Arguments>" tags by analyzing the feature file
                    3. Write JMX flow for all scenarios with their all respective POST, GET calls mentioned in feature file
                    4. COMPULSORILY Add "<thread group>","<transaction controller>", "<ConfigTestElement>" tags in JMX content
                    5. ALSO DON'T FORGET TO ADD "<CSVDataSet>" tag with file name as "testData.csv"
                    6. In the path of each Request STRICTLY add the host variable + post_endpoint value not the post_endpoint variable
                    7. STRICTLY Use Json value from Example in the feature file inside JMX file
                    8. In the Body Data of the Post request STRICTLY add the payload_file Json not the variable name
                    9. For each validation value there should be different "<responseAssertion>" tag with relevant "Assertion.test_field"
                    10. Inside the Response Assertion inside Patterns to Test field pass the status_code value not the variable name
                    11. STRICTLY include 'View Results Tree' at the end of the JMX file content
                    In the example feature file and example JMX for that, all possible different type of scenarios are there,
                    make sure to include ONLY RELEVANT type of scenarios while writing JMX content which are mentioned in input feature file.
                    '''
 
        prompt_header = PromptTemplate(
            input_variables=["data", "jmx", "feature", "generated_jmx"], template=template_header_class)

        qa_prompt_header = LLMChain(
            llm=AzureChatOpenAI(deployment_name="GPT35T16K", model_name="gpt-35-turbo", temperature=0.1,
                                openai_api_key="0b1d7d099829418fb1293b97f2ae9c23",
                                openai_api_base="https://exploregenaiworkspace.openai.azure.com",
                                openai_api_version="2023-03-15-preview"),
            prompt=prompt_header)
 
        output_qa_prompt_header = qa_prompt_header.run(
            {'data': data,
             'jmx': jmx,
             'feature': feature,
             'generated_jmx': generated_jmx
             })
        out_path_c = r"jmeterapitest_old.jmx"
        with open(out_path_c, "w") as file:
            file.write(output_qa_prompt_header)
 
        return output_qa_prompt_header