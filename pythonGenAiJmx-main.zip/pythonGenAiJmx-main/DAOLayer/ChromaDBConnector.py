import configparser

from langchain.vectorstores import Chroma
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.document_loaders.csv_loader import CSVLoader
from langchain.document_loaders import DirectoryLoader, TextLoader
from langchain.schema.document import Document
from langchain.document_loaders.base import BaseLoader
import os
import chromadb
from datetime import datetime


# class vectordb:
#
#     def connect(self, collection_name):
#         client = chromadb.PersistentClient(path="./chroma_database")
#         collection = client.get_or_create_collection(name=collection_name)
#         return collection
#
#     def add_collection(self, collection_name, data, metadata, id_list):
#         collection = self.connect(collection_name)
#         collection.add(
#             documents=data,
#             metadatas=metadata,  # [{"source": "my_source"}, {"source": "my_source"}]
#             ids=id_list  # ["id1", "id2"]
#         )
#
#     def query(self, collection_name, query_text, n):
#         collection = self.connect(collection_name)
#         results = collection.query(
#             query_texts=[query_text],
#             n_results=n
#         )
#         # print(results)
#         return results

class ChromaDBConnector:

    def __init__(self, persist_directory,config_file_path='../Utilities/config.properties'):
        self.config = configparser.ConfigParser()
        self.config_file_path = config_file_path
        self.embeddings = None
        self.model_name = None
        self.model_path = None
        self.threshold = None
        self.persist_directory = persist_directory
        self.context = ''
        self.timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        # updates the instance variables according to the config.properties file
        self.load_config()

    def load_config(self):
        try:
            # Reading the properties defined in the config.properties file
            # updating the model_name and model_path
            self.config.read(self.config_file_path)
            self.model_name = self.config.get('EmbeddingModels', 'embedding_model_name')
            self.model_path = self.config.get("EmbeddingModels", 'embedding_model_path')
            self.embeddings = HuggingFaceEmbeddings(model_name=self.model_name, cache_folder=self.model_path)
            self.threshold = self.config.get('EmbeddingModels', 'external_model_threshold')
        except:
            # updating the threshold value from config.properties file with default_model threshold.
            self.embeddings = HuggingFaceEmbeddings()
            self.threshold = self.config.get('EmbeddingModels', 'default_model_threshold')

    def text_store(self,data,metadata,ids):
        client = Chroma(persist_directory=self.persist_directory, embedding_function=self.embeddings,collection_metadata={"hnsw:space": "cosine"})
        client.add_texts(data, metadata, ids)
        client.persist()

    def vectordb_store_dir(self, data_path):
        loader = DirectoryLoader(data_path, glob="**/*.csv", loader_cls=CSVLoader)
        data = loader.load()

        # load it into Chroma
        db = Chroma.from_documents(documents=data, embedding=self.embeddings,
                                   ids=[doc.metadata['source'].split("\\")[-1].split(".")[0] for doc in data], persist_directory=self.persist_directory,collection_metadata={"hnsw:space": "cosine"})
        db.persist()

    def vectordb_store_doc(self, data_path):
        loader = CSVLoader(data_path)
        data = loader.load()
        # print(data)
        # load it into Chroma
        db = Chroma(persist_directory=self.persist_directory, embedding_function=self.embeddings,collection_metadata={"hnsw:space": "cosine"})
        db.persist()
        ids = db.add_documents(documents=data)
        db.persist()
        return len(ids)

    def vectordb_store_code(self, code, f_name):
        data = Document(page_content=code)

        # load it into Chroma
        db = Chroma.from_documents(documents=[data], embedding=self.embeddings,
                                   persist_directory=self.persist_directory, ids=[f_name],collection_metadata={"hnsw:space": "cosine"})
        db.persist()

    def vectordb_store_code_dir(self, data_path):
        loader = DirectoryLoader(data_path, glob="**/*.py", loader_cls=TextLoader)
        data = loader.load()

        # load it into Chroma
        db = Chroma.from_documents(documents=data, embedding=self.embeddings,
                                   ids=[doc.metadata['source'].split("\\")[-1].split(".")[0] for doc in data], persist_directory=self.persist_directory,collection_metadata={"hnsw:space": "cosine"})
        db.persist()

    def retrieval(self, query, k):
        # if os.path.exists(self.persist_directory) and os.path.isdir(self.persist_directory):
        #     print("The folder exists.")
        db = Chroma(persist_directory=self.persist_directory, embedding_function=self.embeddings,collection_metadata={"hnsw:space": "cosine"})
        retrieved_docs = db.similarity_search(query, k=k)
        return retrieved_docs

    def retrieval_context(self, query, k):

        retrieval_dir = r"../CoreLogicLayer/TestPlanning/SharedResources/data/retrieval_context"
        # try:
        #     os.makedirs(retrieval_dir, exist_ok=True)
        # except OSError as e:
        #     print(f"Error creating directory: {e}")

        db = Chroma(persist_directory=self.persist_directory, embedding_function=self.embeddings,collection_metadata={"hnsw:space": "cosine"})
        docs = db.similarity_search_with_score(query, k=k)
        docs_with_similarity_score = {}
        for doc,score in docs:
            print(score,doc)
            docs_with_similarity_score[score]=doc.page_content
        retrieved_docs = db.similarity_search(query, k=k)
        for doc in retrieved_docs:
            content = doc.page_content
            self.context += (content + '\n')

        output_path = f"{retrieval_dir}/retrieved_{self.timestamp}.txt"
        with open(output_path, "a", encoding="utf-8") as file:
            file.write(self.context)
        print(self.threshold)
        return self.context, docs_with_similarity_score,self.threshold


    def get_docs(self):
        db = Chroma(persist_directory=self.persist_directory, embedding_function=self.embeddings,collection_metadata={"hnsw:space": "cosine"})
        return db.get()

    def get_doc_by_id(self, id):
        db = Chroma(persist_directory=self.persist_directory, embedding_function=self.embeddings,collection_metadata={"hnsw:space": "cosine"})
        return db.get(ids=[id])

    def vector_store(self, fpath):

        embedding_path = self.persist_directory

        try:
            os.makedirs(embedding_path, exist_ok=True)
        except OSError as e:
            print(f"Error creating directory: {e}")

        # load the json data
        # loader = DataFrameLoader(df, page_content_column=df.columns)
        loader = CSVLoader(file_path=fpath, encoding="utf-8")
        documents = loader.load()

        # load it into Chroma
        db = Chroma.from_documents(documents, self.embeddings, persist_directory=embedding_path,collection_metadata={"hnsw:space": "cosine"})
        db.persist()