import os
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import padding as asym_padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hmac
from cryptography.hazmat.primitives import constant_time
from DAOLayer.ChromaDBConnector import ChromaDBConnector
# from Src.Constants import DBConstants


class FileDecryptor:
    def decrypt_file(self, input_path, private_key_path, encryption_key_path):
        encryption_key_data = self.read_encryption_key(encryption_key_path)
        private_key = self.load_private_key(private_key_path, encryption_key_data)

        file_path = input_path

        (
            combined_data,
            encrypted_symmetric_key,
            iv,
            ciphertext,
            mac,
        ) = self.read_combined_data(file_path)

        # Compute HMAC over encrypted key, IV, and ciphertext
        hmac_key = os.urandom(32)
        h = hmac.HMAC(hmac_key, hashes.SHA256(), backend=default_backend())
        h.update(encrypted_symmetric_key)
        h.update(iv)
        h.update(ciphertext)
        computed_mac = h.finalize()

        decrypted_symmetric_key = self.decrypt_symmetric_key(
            private_key, encrypted_symmetric_key
        )

        decrypted_data = self.decrypt_data(
            decrypted_symmetric_key, iv, ciphertext
        )
        text_part = decrypted_data.decode('utf-8')
        return text_part

    def read_encryption_key(self, encryption_key_path):
        with open(encryption_key_path, "rb") as key_file:
            return key_file.read()

    def load_private_key(self, private_key_path, encryption_key_data):
        with open(private_key_path, "rb") as private_key_file:
            private_key_data = private_key_file.read()
            private_key = serialization.load_pem_private_key(
                private_key_data,
                password=encryption_key_data,
                backend=default_backend(),
            )
            return private_key

    def read_combined_data(self, file_path):
        with open(file_path, "rb") as file:
            combined_data = file.read()
            # print(combined_data)
            encrypted_symmetric_key = combined_data[:256]
            iv = combined_data[256:272]
            ciphertext = combined_data[272:-64]
            mac = combined_data[-64:-32]
            session = combined_data[-32:]
            return combined_data, encrypted_symmetric_key, iv, ciphertext, mac

    def secure_compare(self, val1, val2):
        return constant_time.bytes_eq(val1, val2)

    def decrypt_symmetric_key(self, private_key, encrypted_symmetric_key):
        return private_key.decrypt(
            encrypted_symmetric_key,
            asym_padding.OAEP(
                mgf=asym_padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None,
            ),
        )

    def decrypt_data(self, decrypted_symmetric_key, iv, ciphertext):
        cipher = Cipher(
            algorithms.AES(decrypted_symmetric_key),
            modes.CFB(iv),
            backend=default_backend(),
        )
        decryptor = cipher.decryptor()
        return decryptor.update(ciphertext) + decryptor.finalize()


def decrpyt(value):
    vi = ChromaDBConnector(os.environ.get("chroma_path"))
    folder_path = value
    encryption_key_path = vi.retrieval("encrypt_key", 1)[0].page_content
    private_key_path = vi.retrieval("private_key", 1)[0].page_content
    decryptor = FileDecryptor()
    result = decryptor.decrypt_file(folder_path, private_key_path, encryption_key_path)
    return result
