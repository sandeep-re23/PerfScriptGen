import mysql.connector
import os
from DAOLayer import decryption


class mySql:
  mysqlName = os.environ.get("MYSQL_DB")
  mysqlHost = os.environ.get("MYSQL_HOST")
  mysqlUName = os.environ.get("MYSQL_USERNAME")
  mysqlPwd = os.environ.get("GENAI_DB_PASSWORD")

  def connect_mysql(self):
    username = self.mysqlUName
    password = decryption.decrpyt(self.mysqlPwd)
    host = self.mysqlHost
    db = self.mysqlName
    db_url = 'mysql://'+username+':'+password+'@'+host+'/'+db
    engine = create_engine(db_url)
    return engine

  def read_data(self, collection_name, limit):
    engine = self.connect_mysql()
    query ="SELECT * FROM "+collection_name+" LIMIT "+str(limit)
    df = pd.read_sql_query(query,engine)
    del df['id']
    engine.dispose()
    if limit > 0:
      return df.head(limit)
    else:
      return df

  def write_data(self, collection_name, data_frame):
    engine = self.connect_mysql()
    data_frame.to_sql(collection_name, engine, if_exists='append', index=False)
    engine.dispose()
