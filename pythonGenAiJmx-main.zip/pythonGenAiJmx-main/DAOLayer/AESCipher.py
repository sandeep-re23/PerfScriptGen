import base64
from Crypto.Cipher import AES
from hashlib import pbkdf2_hmac

class AESCipher(object):
    def __init__(self):
        self.bridge = "trasnhns"
        self.town = "ffomvtjf"
        self.church = "ptesidet"
        self.park = "rnkrlmar"
        self.bs = 16  # Block size for AES
        self.key_1 = self.get_key(self.bridge, self.town)
        self.iv = self.get_init_vector(self.church, self.park)
        self.key = pbkdf2_hmac(hash_name='sha1', password=str.encode(self.key_1),
                              salt=str.encode(self.iv), iterations=65556,
                              dklen=32)

    def encrypt(self, data):
        data = self._pad(data)
        cipher = AES.new(self.key, AES.MODE_CBC, self.iv.encode())
        encrypted_data = cipher.encrypt(data.encode())
        return base64.b64encode(encrypted_data).decode('utf-8')

    def decrypt(self, encrypted_data):
        encrypted_data = base64.b64decode(encrypted_data)
        cipher = AES.new(self.key, AES.MODE_CBC, self.iv.encode())
        decrypted_data = cipher.decrypt(encrypted_data)
        return self._unpad(decrypted_data.decode('utf-8'))

    def _pad(self, s):
        padding = self.bs - len(s) % self.bs
        return s + padding * chr(padding)

    def _unpad(self, s):
        return s[:-ord(s[len(s)-1:])]

    def get_key(self, part1, part2):
        result = ""
        for i in range(len(part1 + part2)):
            if i % 2 == 1:
                result += part1[i // 2]
            else:
                result += chr(ord(part2[i // 2]) - 1)
        return result

    def get_init_vector(self, part1, part2):
        result = ""
        for i in range(len(part1 + part2)):
            if i % 2 == 1:
                result += part1[i // 2]
            else:
                result += chr(ord(part2[i // 2]) + 1)
        return result
    