import os
import pika
from Controllers import TaskProcessing
import threading
import functools
import time

_DELIVERY_MODE_PERSISTENT = 2

# Configuration
RABBITMQ_HOST = '10.120.100.93'  # 'localhost'
RABBITMQ_PORT = '5672'  # 5672
RABBITMQ_HEARTBEAT = 0
RETRY_DELAY_MS = 1800000
credentials = pika.PlainCredentials(username='neuro',
                                    password='neuro@123')
connection = pika.BlockingConnection(
    pika.ConnectionParameters(host=RABBITMQ_HOST , port=RABBITMQ_PORT,
                              heartbeat=RABBITMQ_HEARTBEAT , credentials=credentials)
)
channel = connection.channel()
channel.queue_declare(queue='genAIQueue', durable=True)

channel.basic_qos(prefetch_count=1)


def extract_keywords(ch, method, properties, body):
    task_processing = TaskProcessing.TaskProcessing()
    text = task_processing.process_task(body, properties.correlation_id)
    # print("ret = " + str(text))
    ch.basic_publish(exchange='',
                     routing_key=properties.reply_to,
                     properties=pika.BasicProperties(correlation_id=properties.correlation_id),
                     body=str(text))
    ch.basic_ack(delivery_tag=method.delivery_tag)


def do_work(connection, channel, delivery_tag, body):
    # Sleeping to simulate 10 seconds of work
    time.sleep(10)

    cb = functools.partial(extract_keywords, channel, delivery_tag)

    connection.add_callback_threadsafe(cb)


def on_message(channel, method_frame, header_frame, body, args):
    (connection, threads) = args

    delivery_tag = method_frame.delivery_tag

    t = threading.Thread(target=do_work, args=(connection, channel, delivery_tag, body))

    t.start()

    threads.append(t)


threads = []
on_message_callback = functools.partial(on_message, args=(connection, threads))

channel.basic_consume(extract_keywords, queue='genAIQueue')
channel.start_consuming()
