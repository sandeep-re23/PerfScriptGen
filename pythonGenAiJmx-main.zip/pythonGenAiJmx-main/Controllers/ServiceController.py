from typing import List
import numpy as np
import os
import io
import json
import zipfile
import datetime
import tempfile
import urllib
import pandas as pd
import uvicorn
import re


from fastapi import UploadFile
from fastapi.middleware.cors import CORSMiddleware
from BaseLayer.ScriptGenBaseModel import ScriptGen, ScriptJmeter
# from passlib.context import CryptContext
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse
from fastapi import FastAPI, Depends, HTTPException
from fastapi.security import OAuth2PasswordRequestForm

from Constants import DBConstants
from Controllers import RPCClient
from DAOLayer.MongoReadWrite import mongoReadWrite



app = FastAPI()

origins = ["http://localhost:3000", "http://10.120.100.13:3000",
           "http://10.10.10.18:3000"]  # Replace with the URL of your React app
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

mongo_obj = mongoReadWrite()
data = []
singleUserStory = ""
data_upload_dir = "../dataupload"


def form_response_ack(corrid):
    data = {}
    data['jobId'] = corrid
    data['startTime'] = datetime.datetime.now().isoformat()
    data['status'] = "STARTED"
    json_data = json.dumps(data)
    return json_data


# @app.post("/login")
# async def login_for_access_token(form_data: OAuth2PasswordRequestForm = Depends()):
#     user = await authenticate_user(form_data.username, form_data.password)
#     if not user:
#         raise HTTPException(
#             status_code=401,
#             detail="Incorrect username or password",
#             headers={"WWW-Authenticate": "Bearer"},
#         )
#
#     access_token = await create_access_token(data={"sub": user.username})
#     return {"access_token": access_token, "token_type": "bearer", "username": user.username, "role": user.role}
#
#
# @app.post("/register")
# async def register_user(user: User):
#     existingUser = mongo_obj.read_data_with_filter(DBConstants.USERS_COLLECTION,
#                                                    "username::eq::" + user.username, 1)
#     if not existingUser.empty:
#         raise HTTPException(status_code=403, detail="User with the same username already exist")
#
#     pwd_context = CryptContext(schemes=["bcrypt"])
#     df = pd.DataFrame(
#         {'username': user.username, 'email': user.email, 'password_hash': pwd_context.encrypt(user.password_hash),
#          'role': user.role},
#         index=[0])
#     return mongo_obj.write_data(DBConstants.USERS_COLLECTION, df)
#
#
# @app.get("/user")
# async def get_users(current_user: User = Depends(get_current_user)):
#     df = mongo_obj.read_data(DBConstants.USERS_COLLECTION, 0)
#     usersList = []
#     if not df.empty:
#         del df['password_hash']
#         usersList = [DisplayUser(**row) for _, row in df.iterrows()]
#     return usersList
#
#
# @app.put("/user")
# async def update_user(user: User, current_user: User = Depends(get_current_user)):
#     if user.password_hash != "":
#         pwd_context = CryptContext(schemes=["bcrypt"])
#         user.password_hash = pwd_context.encrypt(user.password_hash)
#     else:
#         del user.password_hash
#
#     data = user.dict()
#
#     result = mongo_obj.update_record_with_filter(DBConstants.USERS_COLLECTION, "username", user.username, data)
#
#     # result = mongo_obj.update_record_based_on_id(DBConstants.USERS_COLLECTION, id, data)
#
#     # Check if the document was found and updated
#     if result.modified_count == 0:
#         raise HTTPException(status_code=404, detail="User not found")
#
#     # Set the item_id in the response
#     # return {**data, "_id": id}
#     return result.modified_count
#
#
# @app.delete("/user")
# async def remove_user(username: str, current_user: User = Depends(get_current_user)):
#     count = mongo_obj.delete_record_with_filter(DBConstants.USERS_COLLECTION, "username", username)
#     if count == 0:
#         raise HTTPException(status_code=404, detail="User not found")
#     return count
#
#
# @app.get("/user/project")
# async def get_user_projects(current_user: User = Depends(get_current_user)):
#     df = mongo_obj.read_data(DBConstants.PROJECT_COLLECTION, 0)
#     projectList = [Project(**row) for _, row in df.iterrows()]
#     userProjects = []
#     for project in projectList:
#         if project.users is not None:
#             for user in project.users:
#                 if current_user.username == user.username:
#                     del project.users
#                     userProjects.append(project)
#     return userProjects
#
#
# @app.post("/project")
# async def create_project(project: Project, current_user: User = Depends(get_current_user)):
#     print(project, current_user)
#     existingProject = mongo_obj.read_data_with_filter(DBConstants.PROJECT_COLLECTION,
#                                                       "project_id::eq::" + project.project_id, 1)
#     if not existingProject.empty:
#         raise HTTPException(status_code=403, detail="Project with the same id already exist")
#     df = pd.DataFrame({
#         'project_id': project.project_id,
#         'name': project.name,
#         'users': None
#     }, index=[0])
#     return mongo_obj.write_data(DBConstants.PROJECT_COLLECTION, df)
#
#
# @app.get("/project")
# async def get_project(current_user: User = Depends(get_current_user)):
#     df = mongo_obj.read_data(DBConstants.PROJECT_COLLECTION, 0)
#     projectList = [Project(**row) for _, row in df.iterrows()]
#     return projectList
#
#
# @app.put("/project")
# async def update_project(project: Project, current_user: User = Depends(get_current_user)):
#     data = project.dict()
#
#     # Update data in database
#     result = mongo_obj.update_record_with_filter(DBConstants.PROJECT_COLLECTION, "project_id", project.project_id, data)
#     # result = mongo_obj.update_record_based_on_id(DBConstants.PROJECT_COLLECTION, project_id, data)
#
#     # Check if the document was found and updated
#     if result.modified_count == 0:
#         raise HTTPException(status_code=404, detail="Project not found")
#
#     # Set the item_id in the response
#     return {**data}
#
#
# @app.delete("/project")
# async def delete_project(project_id: str, current_user: User = Depends(get_current_user)):
#     count = mongo_obj.delete_record_with_filter(DBConstants.PROJECT_COLLECTION, "project_id", project_id)
#     if count == 0:
#         raise HTTPException(status_code=404, detail="Project not found")
#     return count
#
#
# @app.put("/projectUserMapping/remove")
# async def remove_project_to_user_mapping(project_id: str, username: str, user: User = Depends(get_current_user)):
#     project_dict = mongo_obj.read_data_with_filter(DBConstants.PROJECT_COLLECTION, "project_id::eq::" + project_id, 1)
#     user_dict = mongo_obj.read_data_with_filter(DBConstants.USERS_COLLECTION, "username::eq::" + username, 1)
#
#     if user_dict is None or project_dict is None:
#         raise HTTPException(status_code=404, detail="Either project or user with the given id doesn't exist")
#
#     user_data = user_dict.iloc[0, :]
#     user = User(**user_data.to_dict())
#     project_data = project_dict.iloc[0, :]
#     project = Project(**project_data.to_dict())
#     usersList = project.users
#     for existingUser in usersList:
#         if existingUser.username == user.username:
#             usersList.remove(existingUser)
#     project.users = usersList
#     result = mongo_obj.update_record_with_filter(DBConstants.PROJECT_COLLECTION, "project_id", project_id,
#                                                  project.dict())
#
#     # Check if the document was found and updated
#     if result.modified_count == 0:
#         raise HTTPException(status_code=422, detail="Unable to remove user from the project")
#
#     return result.modified_count
#
#
# @app.put("/projectUserMapping")
# async def project_to_user_mapping(project_id: str, username: str, user: User = Depends(get_current_user)):
#     project_dict = mongo_obj.read_data_with_filter(DBConstants.PROJECT_COLLECTION, "project_id::eq::" + project_id, 1)
#     user_dict = mongo_obj.read_data_with_filter(DBConstants.USERS_COLLECTION, "username::eq::" + username, 1)
#     if user_dict is None or project_dict is None:
#         raise HTTPException(status_code=404, detail="Either project or user with the given id doesn't exist")
#
#     user_data = user_dict.iloc[0, :]
#     user = User(**user_data.to_dict())
#     project_data = project_dict.iloc[0, :]
#     project = Project(**project_data.to_dict())
#     usersList = project.users
#     if usersList is None:
#         usersList = []
#     usersList.append(user)
#     project.users = usersList
#     result = mongo_obj.update_record_with_filter(DBConstants.PROJECT_COLLECTION, "project_id", project_id,
#                                                  project.dict())
#
#     # Check if the document was found and updated
#     if result.modified_count == 0:
#         raise HTTPException(status_code=422, detail="Unable to map user to the project")
#
#     return result.modified_count
#
#
# @app.get("/homepage")
# async def homepage(current_user: User = Depends(get_current_user)):
#     return {"message": f"Hello, {current_user.username}!"}

@app.post("/generateJMX")
async def create_jmx(item: ScriptJmeter):
    global rpcClient
    if rpcClient is None:
        rpcClient = RPCClient.RpcClient("rpcQueue")
    data = item.dict()
    data['phase'] = 'GenerateJMX'
    data['model_name'] = "gpt-35-turbo"
    content = json.dumps(data)
    corr_id = rpcClient.send_request(content)
    resp_ack = form_response_ack(corr_id)
    return resp_ack

@app.get("/test")
async def test():
    return "tested"

#
# @app.post("/generateBDD")
# async def create_bdd(item: BDD):
#     global rpcClient
#     if rpcClient is None:
#         rpcClient = RPCClient.RpcClient("rpcQueue")
#     data = item.dict()
#     data['phase'] = 'GenerateBDD'
#     data['model_name'] = "gpt-35-turbo"
#     content = json.dumps(data)
#     corr_id = rpcClient.send_request(content)
#     resp_ack = form_response_ack(corr_id)
#     return resp_ack
#
#
# @app.post("/generateTC")
# async def create_tc(item: TCS):
#     global rpcClient
#     if rpcClient is None:
#         rpcClient = RPCClient.RpcClient("rpcQueue")
#     data = item.dict()
#     data['phase'] = 'ManualTestCaseGeneration'
#     data['model_name'] = 'gpt-35-turbo'
#     content = json.dumps(data)
#     corr_id = rpcClient.send_request(content)
#     resp_ack = form_response_ack(corr_id)
#     return resp_ack
#
#
# @app.post("/generateFormattedTC")
# async def create_formatted_tc(item: Formatted_TC):
#     data = item.dict()
#     data['model_name'] = 'gpt-35-turbo'
#     output = generate_formatted_tcs(data)
#
#     with tempfile.NamedTemporaryFile(delete=False, mode='w', suffix='.txt') as temp_file:
#         temp_file.write(output)
#
#     filename = "formatted_manual_tc.txt"
#
#     # Return the file as a response for download
#     return FileResponse(temp_file.name, media_type='text/plain',
#                         headers={"Content-Disposition": f"attachment; filename={filename}"})
#
#
# @app.post("/UserStoryToTestData")
# async def create_test_data_from_user_story(item: TestDataFromUserStory):
#     global rpcClient
#     if rpcClient is None:
#         rpcClient = RPCClient.RpcClient("rpcQueue")
#     data = item.dict()
#     data['phase'] = 'UserStoryToTestData'
#     data['model_name'] = 'gpt-35-turbo'
#     content = json.dumps(data)
#     corr_id = rpcClient.send_request(content)
#     resp_ack = form_response_ack(corr_id)
#     return resp_ack
#
#
# @app.post("/generateASTC")
# async def create_tc_from_automation_script(item: ASTCS):
#     print("inside /generateASTC")
#     print(item)
#     global rpcClient
#     if rpcClient is None:
#         rpcClient = RPCClient.RpcClient("rpcQueue")
#     data = item.dict()
#     data['phase'] = 'AutomationScriptToManualTestCaseGeneration'
#     data['model_name'] = 'gpt-35-turbo'
#     content = json.dumps(data)
#     corr_id = rpcClient.send_request(content)
#     resp_ack = form_response_ack(corr_id)
#     return resp_ack
#
#
# @app.get("/getBDDResults/")
# async def getBDD(jobID: str):
#     resp = get_bdd_result(jobID)
#     return resp
#
#
# @app.get("/userStoryToTestDataResult/")
# async def getTestDataFromUserStory(jobID: str):
#     resp = userStoryToTestDataResult(jobID)
#     return resp
#
#
# @app.get("/getTCResults/")
# async def getTC(jobID: str):
#     resp = get_tcs_result(jobID)
#     return resp
#
#
# @app.post("/generateAutomationScript")
# async def script_generation(item: ScriptGen):
#     global rpcClient
#     if rpcClient is None:
#         rpcClient = RPCClient.RpcClient("rpcQueue")
#     data = item.dict()
#     if data['isBDD']:
#         data['phase'] = 'GenerateStepDefinition'
#     elif data['isModular']:
#         data['phase'] = 'GenerateAutomationScript'
#     data['crawl'] = True
#     data['model_name'] = 'gpt-35-turbo'
#     content = json.dumps(data)
#     corr_id = rpcClient.send_request(content)
#     resp_ack = form_response_ack(corr_id)
#     return resp_ack
#
#
# @app.post("/generateCypressWebTs")
# async def playwright_script_generation(item: CypressWebBaseModel):
#     global rpcClient
#     if rpcClient is None:
#         rpcClient = RPCClient.RpcClient("rpcQueue")
#     data = item.dict()
#     data['phase'] = 'GenerateCypressWebTs'
#     data['crawl'] = True
#     data['model_name'] = 'gpt-35-turbo'
#     content = json.dumps(data)
#     corr_id = rpcClient.send_request(content)
#     resp_ack = form_response_ack(corr_id)
#     return resp_ack
# @app.post("/generateAutomationScriptNoCrawl")
# async def script_generation_no_crawl(item: ScriptGenNoCrawl):
#     global rpcClient
#     if rpcClient is None:
#         rpcClient = RPCClient.RpcClient("rpcQueue")
#     data = item.dict()
#     data['phase'] = 'GenerateAutomationScript'
#     data['crawl'] = False
#     data['model_name'] = 'gpt-35-turbo'
#     content = json.dumps(data)
#     corr_id = rpcClient.send_request(content)
#     resp_ack = form_response_ack(corr_id)
#     return resp_ack
#
#
# @app.post("/generateAPIRestassuredScript")
# async def apiscriptgeneration(item: APIScriptGen):
#     global rpcClient
#     if rpcClient is None:
#         rpcClient = RPCClient.RpcClient("rpcQueue")
#     data = item.dict()
#     data['phase'] = 'GenerateAPIRestassuredScript'
#     data['model_name'] = 'gpt-35-turbo'
#     content = json.dumps(data)
#     corr_id = rpcClient.send_request(content)
#     resp_ack = form_response_ack(corr_id)
#
#
# @app.post("/generateJmeterScript")
# async def jmeterscriptgeneration(item: JMXScriptGen):
#     global rpcClient
#     if rpcClient is None:
#         rpcClient = RPCClient.RpcClient("rpcQueue")
#     data = item.dict()
#     data['phase'] = 'GenerateJmeterScript'
#     data['model_name'] = 'gpt-35-turbo'
#     content = json.dumps(data)
#     corr_id = rpcClient.send_request(content)
#     resp_ack = form_response_ack(corr_id)
#
#
# @app.get("/getStatus")
# async def getStatus(jobID: str):
#     df = mongo_obj.read_data_with_filter(DBConstants.EXECUTION_SUMMARY_COLLECTION, "jobID::eq::" + jobID, 0)
#
#     # Filter the DataFrame to include only specific columns
#     # columns_to_return = ["jobID", "executionStatus", "input", "output", "timeTaken"]
#     # filtered_df = df[df["jobID"] == jobID][columns_to_return]
#
#     if not df.empty:
#         # Convert the filtered DataFrame to a dictionary
#         # response_data = df[df["jobID"] == jobID].iloc[0].to_dict()
#         data = df.to_json(orient="records")
#         return json.loads(data)
#     else:
#         return JSONResponse(content={"message": "No data found for the specified jobID"})
#
#
# @app.get("/getExecutionSummary")
# async def getExecutionSummary(projectID: str):
#     try:
#         # df = mongo_obj.read_data_executedOn(DBConstants.EXECUTION_SUMMARY_COLLECTION, 50)
#         df = mongo_obj.read_data_with_filter(DBConstants.EXECUTION_SUMMARY_COLLECTION, "projectID::eq::" + projectID,
#                                              50)
#         df['executedOn'] = pd.to_datetime(df['executedOn'])
#
#         # Sort by "executedOn" in descending order
#         df = df.sort_values(by='executedOn', ascending=False)
#         # Convert the "executedOn" column back to a string format
#         df['executedOn'] = df['executedOn'].dt.strftime("%dth %b, %Y %H:%M:%S")
#         data = df.to_json(orient="records")
#         return json.loads(data)
#     except:
#         return []
#
#
# @app.get("/getGenerateOptions")
# async def generationOption(jobID: str):
#     df = mongo_obj.read_data_with_filter(DBConstants.EXECUTION_SUMMARY_COLLECTION, "jobID::eq::" + jobID, 0)
#     dictionary = eval(df.iloc[0]['generationOption'])
#     return dictionary
#
#
# @app.get("/downloadBDDGeneratedFile")
# async def download_bdd_generated(jobID: str, userStoryID: str):
#     bdd_df = mongo_obj.read_data_with_filter(DBConstants.BDD_COLLECTION,
#                                              "userStoryID::eq::" + userStoryID + "<<>>jobID::eq::" + jobID,
#                                              0)
#
#     with tempfile.NamedTemporaryFile(delete=False, mode='w', suffix='.txt') as temp_file:
#         temp_file.write(bdd_df.iloc[0]['generatedBDD'])
#
#     filename = f"{bdd_df.iloc[0]['userStoryID']}.txt"
#
#     # Return the file as a response for download
#     return FileResponse(temp_file.name, media_type='text/plain',
#                         headers={"Content-Disposition": f"attachment; filename={filename}"})
#
#
# @app.get("/downloadTCGeneratedFile")
# async def download_tcs_generated(jobID: str, userStoryID: str):
#     tcs_df = mongo_obj.read_data_with_filter(DBConstants.TESTCASE_COLLECTION,
#                                              "userStoryID::eq::" + userStoryID + "<<>>jobID::eq::" + jobID,
#                                              0)
#
#     with tempfile.NamedTemporaryFile(delete=False, mode='w', suffix='.txt') as temp_file:
#         temp_file.write(tcs_df.iloc[0]['generatedTCS'])
#
#     filename = f"{tcs_df.iloc[0]['userStoryID']}.txt"
#
#     # Return the file as a response for download
#     return FileResponse(temp_file.name, media_type='text/plain',
#                         headers={"Content-Disposition": f"attachment; filename={filename}"})
#
#
# @app.get("/downloadTDGeneratedFile")
# async def download_td_generated(jobID: str, userStoryID: str):
#     td_df = mongo_obj.read_data_with_filter(DBConstants.USER_STORY_TO_TEST_DATA_COLLECTION,
#                                             "userStoryID::eq::" + userStoryID + "<<>>jobID::eq::" + jobID,
#                                             0)
#
#     with tempfile.NamedTemporaryFile(delete=False, mode='w', suffix='.txt') as temp_file:
#         temp_file.write(td_df.iloc[0]['generatedTestCases'] + "\n" + td_df.iloc[0]['generatedTestData'])
#
#     filename = f"{td_df.iloc[0]['userStoryID']}.txt"
#
#     # Return the file as a response for download
#     return FileResponse(temp_file.name, media_type='text/plain',
#                         headers={"Content-Disposition": f"attachment; filename={filename}"})
#
#
# @app.get("/downloadBDDGeneratedZip")
# async def download_bdd_generated(jobID: str):
#     df = read_bdd_data(jobID)
#     files_data = []
#
#     for data in df[['generatedBDD', 'userStoryID']].values:
#         file_content = data[0]
#         filename = f"{data[1]}.txt"
#         files_data.append((filename, file_content))
#
#     zip_buffer = create_zip_archive(files_data)
#
#     # Define the custom filename for the downloaded file
#     custom_filename = f"BDD_Data_{datetime.datetime.now().strftime('%d-%m-%y-%H-%M-%S')}.zip"
#
#     # Return the zip file as a StreamingResponse
#     return StreamingResponse(io.BytesIO(zip_buffer.read()), media_type='application/zip',
#                              headers={"Content-Disposition": f"attachment; filename={custom_filename}"})
#
#
# @app.get("/downloadTCGeneratedZip")
# async def download_tcs_generated(jobID: str):
#     df = read_tcs_data(jobID)
#     files_data = []
#
#     for data in df[['generatedTCS', 'userStoryID']].values:
#         file_content = data[0]
#         filename = f"{data[1]}.txt"
#         files_data.append((filename, file_content))
#
#     zip_buffer = create_zip_archive(files_data)
#
#     # Define the custom filename for the downloaded file
#     custom_filename = f"TCS_Data_{datetime.datetime.now().strftime('%d-%m-%y-%H-%M-%S')}.zip"
#
#     # Return the zip file as a StreamingResponse
#     return StreamingResponse(io.BytesIO(zip_buffer.read()), media_type='application/zip',
#                              headers={"Content-Disposition": f"attachment; filename={custom_filename}"})
#
#
# @app.get("/downloadTDGeneratedZip")
# async def download_td_generated(jobID: str):
#     df = read_test_data(jobID)
#     files_data = []
#
#     for data in df[['generatedTestCases', 'generatedTestData', 'userStoryID']].values:
#         file_content = data[0] + "\n" + data[1]
#         filename = f"{data[2]}.txt"
#         files_data.append((filename, file_content))
#
#     zip_buffer = create_zip_archive(files_data)
#
#     # Define the custom filename for the downloaded file
#     custom_filename = f"TD_Data_{datetime.datetime.now().strftime('%d-%m-%y-%H-%M-%S')}.zip"
#
#     # Return the zip file as a StreamingResponse
#     return StreamingResponse(io.BytesIO(zip_buffer.read()), media_type='application/zip',
#                              headers={"Content-Disposition": f"attachment; filename={custom_filename}"})
#
#
# @app.get("/downloadMultipleTemplate")
# async def download_bdd_template_multiple():
#     file_path = r"../CoreLogicLayer/TestPlanning/SharedResources/template/bdd_template.xlsx"
#     if os.path.exists(file_path):
#         return FileResponse(file_path,
#                             filename=os.path.basename(file_path))
#     else:
#         return {"error": "File not found"}
#
#
# @app.get("/downloadSingleTemplate")
# async def download_bdd_template_single():
#     file_path = r"../CoreLogicLayer/TestPlanning/SharedResources/template/bdd_template.txt"
#     if os.path.exists(file_path):
#         return FileResponse(file_path,
#                             filename=os.path.basename(file_path))
#     else:
#         return {"error": "File not found"}
#
#
# @app.get("/downloadSingleTCTemplate")
# async def download_bdd_template_single():
#     file_path = r"../CoreLogicLayer/TestPlanning/SharedResources/template/tc_template.txt"
#     if os.path.exists(file_path):
#         return FileResponse(file_path,
#                             filename=os.path.basename(file_path))
#     else:
#         return {"error": "File not found"}
#
#
# @app.get("/downloadGeneratedScriptFolder")
# async def download_script_folder(jobID):
#     zip_file = mongo_obj.read_zip_from_gridfs(DBConstants.SCRIPTS_COLLECTION, jobID)
#     if zip_file:
#         # Create a buffer to store the ZIP file contents
#         buffer = io.BytesIO(zip_file.read())
#
#         # Create a StreamingResponse to send the ZIP file as a download
#         return StreamingResponse(
#             buffer,
#             media_type="application/zip",
#             headers={"Content-Disposition": f"attachment; filename*=UTF-8''{urllib.parse.quote(zip_file.filename)}"}
#         )
#     else:
#         return {"message": "ZIP file not found for the specified jobID"}
#
#
# @app.get("/downloadGeneratedStepDefFolder")
# async def download_step_def_script_folder(jobID):
#     zip_file = mongo_obj.read_zip_from_gridfs(DBConstants.BDD_TO_SETPDEFS_SCRIPTS_COLLECTION, jobID)
#     if zip_file:
#         # Create a buffer to store the ZIP file contents
#         buffer = io.BytesIO(zip_file.read())
#
#         # Create a StreamingResponse to send the ZIP file as a download
#         return StreamingResponse(
#             buffer,
#             media_type="application/zip",
#             headers={"Content-Disposition": f"attachment; filename*=UTF-8''{urllib.parse.quote(zip_file.filename)}"}
#         )
#     else:
#         return {"message": "ZIP file not found for the specified jobID"}
#
#
# @app.get("/downloadGeneratedAPIScriptFolder")
# async def download_API_script_folder(jobID):
#     zip_file = mongo_obj.read_zip_from_gridfs(DBConstants.API_SCRIPTS_COLLECTION, jobID)
#     if zip_file:
#         # Create a buffer to store the ZIP file contents
#         buffer = io.BytesIO(zip_file.read())
#
#         # Create a StreamingResponse to send the ZIP file as a download
#         return StreamingResponse(
#             buffer,
#             media_type="application/zip",
#             headers={"Content-Disposition": f"attachment; filename*=UTF-8''{urllib.parse.quote(zip_file.filename)}"}
#         )
#     else:
#         return {"message": "ZIP file not found for the specified jobID"}
#
#
# @app.get("/downloadGeneratedJMXScriptFolder")
# async def download_JMX_script_folder(jobID):
#     zip_file = mongo_obj.read_zip_from_gridfs(DBConstants.JMX_SCRIPTS_COLLECTION, jobID)
#     if zip_file:
#         # Create a buffer to store the ZIP file contents
#         buffer = io.BytesIO(zip_file.read())
#
#         # Create a StreamingResponse to send the ZIP file as a download
#         return StreamingResponse(
#             buffer,
#             media_type="application/zip",
#             headers={"Content-Disposition": f"attachment; filename*=UTF-8''{urllib.parse.quote(zip_file.filename)}"}
#         )
#     else:
#         return {"message": "ZIP file not found for the specified jobID"}
#
#
# @app.post("/uploadfile")
# async def upload_file(file: UploadFile):
#     try:
#         file_content = await file.read()
#         mongo_obj.store_file_in_mongodb(DBConstants.FILES_COLLECTION, file_content, file_name=file.filename,
#                                         content_type=file.content_type)
#         return JSONResponse(content={"message": "File uploaded successfully"}, status_code=200)
#     except Exception as e:
#         return JSONResponse(content={"message": f"An error occurred: {str(e)}"}, status_code=500)

#
# @app.get("/getGeneratedData")
# async def get_data():
#     bdd_data = 0
#     tc_data = 0
#     api_data = 0
#     automation_data = 0
#     try:
#         bdd_df = mongo_obj.read_data_with_filter(DBConstants.EXECUTION_SUMMARY_COLLECTION,
#                                                  "useCaseName::eq::BDD Feature File Generation", 0)
#         for i in range(len(bdd_df)):
#             if bdd_df.iloc[i]['output'] != 'N/A':
#                 bdd_data += int(bdd_df.iloc[i]['output'])
#     except:
#         pass
#
#     try:
#         tc_df = mongo_obj.read_data_with_filter(DBConstants.EXECUTION_SUMMARY_COLLECTION,
#                                                 "useCaseName::eq::Manual Test Case Generation", 0)
#         for i in range(len(tc_df)):
#             if tc_df.iloc[i]['output'] != 'N/A':
#                 tc_data += int(tc_df.iloc[i]['output'])
#     except:
#         pass
#
#     try:
#         automation_df = mongo_obj.read_data_with_filter(DBConstants.EXECUTION_SUMMARY_COLLECTION,
#                                                         "useCaseName::eq::Automation Script Generation", 0)
#         for i in range(len(automation_df)):
#             if automation_data.iloc[i]['output'] != 'N/A':
#                 automation_data += int(automation_data.iloc[i]['output'])
#     except:
#         pass
#
#     try:
#         api_df = mongo_obj.read_data_with_filter(DBConstants.EXECUTION_SUMMARY_COLLECTION,
#                                                  "useCaseName::eq::API Script Generation", 0)
#         for i in range(len(api_df)):
#             if api_df.iloc[i]['output'] != 'N/A':
#                 api_data += int(api_df.iloc[i]['output'])
#     except:
#         pass
#
#     return {"BDD": bdd_data, "TC": tc_data, 'API': api_data, 'Automation': automation_data}
#
#
# @app.get("/getAdditionalContextBDD")
# async def get_additional_context_data(projectID: str):
#     try:
#         dataframes = mongo_obj.read_additional_context(projectID, ADDITIONAL_CONTEXT)
#         combined_df = pd.concat(dataframes, ignore_index=True)
#         return {
#             "message": "We have a total of " + str(len(combined_df)) + " historical context. Do you want to add more?"}
#     except:
#         return {"message": "We don't have any historical context. Upload some data."}
#
#
# @app.get("/getAdditionalContextTC")
# async def get_additional_context_data_tc(projectID: str):
#     try:
#         dataframes = mongo_obj.read_additional_context(projectID, ADDITIONAL_CONTEXT_TC)
#         combined_df = pd.concat(dataframes, ignore_index=True)
#         return {
#             "message": "We have a total of " + str(len(combined_df)) + " historical context. Do you want to add more?"}
#     except:
#         return {"message": "We don't have any historical context. Upload some data."}
#
#
# @app.get("/getAdditionalContextTD")
# async def get_additional_context_data_td(projectID: str):
#     try:
#         dataframes = mongo_obj.read_additional_context(projectID, ADDITIONAL_CONTEXT_TD)
#         combined_df = pd.concat(dataframes, ignore_index=True)
#         return {
#             "message": "We have a total of " + str(len(combined_df)) + " historical context. Do you want to add more?"}
#     except:
#         return {"message": "We don't have any historical context. Upload some data."}
#
#
# @app.post("/uploadAdditionalContextBDD")
# async def upload_additional_context(projectID: str, file: UploadFile):
#     try:
#         file_content = await file.read()
#         mongo_obj.store_additional_context_in_mongodb(DBConstants.ADDITIONAL_CONTEXT, file_content,
#                                                       file_name=file.filename,
#                                                       content_type=file.content_type, project_id=projectID)
#         return JSONResponse(content={"message": "File uploaded successfully"}, status_code=200)
#     except Exception as e:
#         return JSONResponse(content={"message": f"An error occurred: {str(e)}"}, status_code=500)
#
#
# @app.post("/uploadAdditionalContextTC")
# async def upload_additional_context_tc(projectID: str, file: UploadFile):
#     try:
#         file_content = await file.read()
#         mongo_obj.store_additional_context_in_mongodb(DBConstants.ADDITIONAL_CONTEXT_TC, file_content,
#                                                       file_name=file.filename,
#                                                       content_type=file.content_type, project_id=projectID)
#         return JSONResponse(content={"message": "File uploaded successfully"}, status_code=200)
#     except Exception as e:
#         return JSONResponse(content={"message": f"An error occurred: {str(e)}"}, status_code=500)
#
#
# @app.post("/uploadAdditionalContextTD")
# async def upload_additional_context(projectID: str, file: UploadFile):
#     try:
#         file_content = await file.read()
#         mongo_obj.store_additional_context_in_mongodb(DBConstants.ADDITIONAL_CONTEXT_TD, file_content,
#                                                       file_name=file.filename,
#                                                       content_type=file.content_type, project_id=projectID)
#         return JSONResponse(content={"message": "File uploaded successfully"}, status_code=200)
#     except Exception as e:
#         return JSONResponse(content={"message": f"An error occurred: {str(e)}"}, status_code=500)
#
#
# @app.post("/uploadfiles")
# async def upload_files(files: List[UploadFile]):
#     # Process the uploaded files
#     try:
#         for file in files:
#             file_content = await file.read()
#             mongo_obj.store_file_in_mongodb(DBConstants.FILES_COLLECTION, file_content, file_name=file.filename,
#                                             content_type=file.content_type)
#         return JSONResponse(content={"message": "Files uploaded successfully"}, status_code=200)
#     except Exception as e:
#         return JSONResponse(content={"message": f"An error occurred: {str(e)}"}, status_code=500)
#
#
# @app.post("/uploadFrameworkZipFolder")
# async def upload_zip_folder(projectID: str, file: UploadFile, type: str):
#     # Check if the uploaded file is a zip file
#     if not file.filename.endswith(".zip"):
#         return {"error": "Uploaded file is not a zip file"}
#
#     try:
#         if type == "Framework Folder":
#             path = PathConstants.SELE_JAVA_FRAMEWORK_FOLDER
#             if not os.path.exists(path):
#                 os.makedirs(path)
#         elif type == "Scripts Folder":
#             path = PathConstants.SELE_JAVA_SCRIPTS_FOLDER
#             if not os.path.exists(path):
#                 os.makedirs(path)
#
#         file_content = await file.read()
#         mongo_obj.upload_zip_projectID(DBConstants.FRAMEWORK_COLLECTION, file_content,
#                                        file_name=file.filename,
#                                        content_type=file.content_type, project_id=projectID,
#                                        folder_type=type)
#
#         abs_path = os.path.abspath(path)
#         abs_path = r'//?/' + abs_path
#
#         file_stream = io.BytesIO(file_content)
#         file_stream.seek(0)  # Ensure the cursor is at the beginning of the stream
#
#         # Extract the zip file
#         with zipfile.ZipFile(file_stream, "r") as zip_ref:
#             zip_ref.extractall(abs_path)
#
#         extract_dir = os.path.join(path, file.filename.split('.')[0])
#         print(extract_dir)
#
#         return {"message": "ZIP file uploaded and extracted successfully"}
#
#     except Exception as e:
#         return {"error": f"An error occurred: {str(e)}"}
#
#
# @app.get("/getFrameworkZipFolder")
# async def get_zip_folder(projectID: str, type: str):
#     try:
#         if type == "Framework Folder":
#             path = PathConstants.SELE_JAVA_FRAMEWORK_FOLDER
#             if not os.path.exists(path):
#                 os.makedirs(path)
#         elif type == "Scripts Folder":
#             path = PathConstants.SELE_JAVA_SCRIPTS_FOLDER
#             if not os.path.exists(path):
#                 os.makedirs(path)
#
#         file_content, file_name = mongo_obj.read_zip_projectID(DBConstants.FRAMEWORK_COLLECTION, projectID, type)
#
#         abs_path = os.path.abspath(path)
#         abs_path = r'//?/' + abs_path
#
#         file_stream = io.BytesIO(file_content)
#         file_stream.seek(0)  # Ensure the cursor is at the beginning of the stream
#
#         # Extract the zip file
#         with zipfile.ZipFile(file_stream, "r") as zip_ref:
#             zip_ref.extractall(abs_path)
#
#         extract_dir = os.path.join(path, file_name.split('.')[0])
#         print(extract_dir)
#
#         return {"message": f"{file_name} ZIP file extracted successfully"}
#
#     except:
#         return {"message": "No ZIP file found for specific projectID"}
#
#
# @app.post("/uploadAutomationFrameworkTC")
# async def upload_framework_scripts_tc(project_id: str, framework: str, file: UploadFile):
#     # Define the custom filename for the downloaded file
#     custom_filename = f"{file.filename.split('.')[0]}_{datetime.datetime.now().strftime('%d-%m-%y-%H-%M-%S')}_{framework}"
#     custom_filename_zip = f"{custom_filename}.zip"
#     print("custom_filename : " + custom_filename)
#     basePath = "../automationScriptTc"
#
#     # name = file.filename.split('.')[0]
#     # existingAutomationScript = mongo_obj.read_data_with_filter(DBConstants.ASTC_COLLECTION, "name::eq::"+name, 1)
#
#     # if not existingAutomationScript.empty:
#     #     return {"error": "AutomationScript with the same name already exists"}
#
#     chroma_obj = ChromaDBConnector(os.path.join(PathConstants.AUTOMATION_FRAMEWORK_SCRIPTS, project_id))
#
#     # Check if the uploaded file is a zip file
#     if not file.filename.endswith(".zip"):
#         return {"error": "Uploaded file is not a zip file"}
#
#     try:
#         # Save the uploaded zip file to the temporary directory
#         zip_path = os.path.join(basePath, custom_filename_zip)
#         print("zip-path : " + zip_path)
#         with open(zip_path, "wb") as temp_file:
#             temp_file.write(file.file.read())
#
#         # Extract the zip file
#         with zipfile.ZipFile(zip_path, "r") as zip_ref:
#             zip_ref.extractall(os.path.join(basePath, custom_filename))
#
#         extract_dir = os.path.join(basePath, custom_filename, file.filename.split('.zip')[0])
#         print("extract-dir : " + extract_dir)
#         chroma_obj.vectordb_store_code_dir(extract_dir)
#         # os.remove(zip_path)
#         rootPath = ""
#         resourcePath = ""
#         if framework == "craft_keyword-driven":
#             rootPath = "/" + custom_filename + "/" + file.filename.split('.zip')[
#                 0] + "/keywordDriven-maven-testng-framework/src/test/java"
#             resourcePath = "/" + custom_filename + "/" + file.filename.split('.zip')[
#                 0] + "/keywordDriven-maven-testng-framework/src/test/resources/Datatables"
#
#         if framework == "craft_module-driven":
#             rootPath = "/" + custom_filename + "/" + file.filename.split('.zip')[
#                 0] + "/modularDriven-maven-testng-framework/src/test/java"
#
#         df = pd.DataFrame(
#             {'name': custom_filename, 'project_id': project_id, 'framework': framework, 'basePath': basePath,
#              'rootPath': rootPath, 'resourcePath': resourcePath},
#             index=[0])
#
#         mongo_obj.write_data(DBConstants.ASTC_COLLECTION, df)
#         # remover = EmptyDirectory()
#         # remover.remove(data_upload_dir)
#         automationScriptListDF = mongo_obj.read_data_with_filter(DBConstants.ASTC_COLLECTION,
#                                                                  "project_id::eq::" + project_id, 0)
#         automationScriptList = [AutomationScriptFramework(**row) for _, row in automationScriptListDF.iterrows()]
#         nameList = []
#         for element in automationScriptList:
#             nameList.append(element.name)
#         return {"message": "ZIP file uploaded and extracted successfully", "data": nameList}
#
#     except Exception as e:
#         return {"error": f"An error occurred: {str(e)}"}
#
#
# @app.get("/availableAutomationFrameworkTC")
# async def get_available_framework_scripts_tc(project_id: str):
#     automationScriptListDF = mongo_obj.read_data_with_filter(DBConstants.ASTC_COLLECTION,
#                                                              "project_id::eq::" + project_id, 0)
#     automationScriptList = [AutomationScriptFramework(**row) for _, row in automationScriptListDF.iterrows()]
#     nameList = []
#     for element in automationScriptList:
#         nameList.append(element.name)
#     return {"data": nameList}
#
#
# @app.get("/downloadGeneratedManualTctFolder")
# async def download_script_folder(jobID):
#     zip_file = mongo_obj.read_zip_from_gridfs(DBConstants.MANUALTC_COLLECTION, jobID)
#     if zip_file:
#         # Create a buffer to store the ZIP file contents
#         buffer = io.BytesIO(zip_file.read())
#
#         # Create a StreamingResponse to send the ZIP file as a download
#         return StreamingResponse(
#             buffer,
#             media_type="application/zip",
#             headers={"Content-Disposition": f"attachment; filename*=UTF-8''{urllib.parse.quote(zip_file.filename)}"}
#         )
#     else:
#         return {"message": "ZIP file not found for the specified jobID"}
#
#
# @app.delete("/delete")
# async def delete_item(jobID: str, useCaseName: str):
#     result_collection_name = {
#         "BDD Feature File Generation": DBConstants.BDD_COLLECTION,
#         "Automation Script Generation": DBConstants.SCRIPTS_COLLECTION,
#         "Manual Test Case Generation": DBConstants.TESTCASE_COLLECTION,
#         "API Script Generation": DBConstants.API_SCRIPTS_COLLECTION
#     }.get(useCaseName, DBConstants.FILES_COLLECTION)  # Default to "Files" if useCaseName is not found in the mapping
#
#     count = mongo_obj.delete_item_based_on_jobID(DBConstants.EXECUTION_SUMMARY_COLLECTION, result_collection_name,
#                                                  jobID)
#     return {"message": f"Item with {jobID} deleted successfully", "deleted_count": count}


if __name__ == "__main__":
    uvicorn.run("ServiceController:app", host="127.0.0.1", port=8000, reload=True)
rpcClient = None  # Initialize it to None
