import json

from CoreLogic.generateJmxinterface import generate_automation_script
# from Src.CoreLogicLayer.IntelligentAutomation.FunctionalTestAutomation.BDDToFeatureFile.main.FeatureInterface import \
#     generate_stepDef_scripts
# from Src.CoreLogicLayer.IntelligentAutomation.FunctionalTestAutomation.JmeterScript.main.JmeterInterface import \
#     generate_jmeter_script
# from Src.CoreLogicLayer.IntelligentAutomation.FunctionalTestAutomation.SharedResources.main.Interface import generate_automation_script
# from Src.CoreLogicLayer.TestPlanning.BDDGeneration.src.Interface import generate_bdd
# from Src.CoreLogicLayer.TestPlanning.ManualTestCaseGeneration.src.Interface import generate_tcs, \
#     generate_tcs_from_automation_script
# from Src.CoreLogicLayer.TestPlanning.TestdataGeneration.src.Interface import generate_test_data_from_user_story
# from Src.CoreLogicLayer.IntelligentAutomation.FunctionalTestAutomation.CypressWebTs.Interface import \
#     generate_cypress_web_ts_interface


class TaskProcessing:

    # def __init__(self):
    #     self.loggers = LoggerUtil.LoggerUtil().getLogger(__name__)

    def process_task(self, input_json, jobID):
        input_value = (input_json.decode("utf-8"))
        processing_json = (json.loads(input_value))
        processing_json['jobID'] = jobID
        processing_json['isContinue'] = False

        try:
            if processing_json['phase'] == 'GenerateJMX':
                resp = generate_automation_script(processing_json)
                return resp

            # elif processing_json['phase'] == 'GenerateBDD':
            #     resp = generate_bdd(processing_json)
            #     return resp
            #
            # elif processing_json['phase'] == 'ManualTestCaseGeneration':
            #     resp = generate_tcs(processing_json)
            #     return resp
            #
            # elif processing_json['phase'] == 'AutomationScriptToManualTestCaseGeneration':
            #     resp = generate_tcs_from_automation_script(processing_json)
            #     return resp
            #
            # elif processing_json['phase'] == 'GenerateAPIRestassuredScript':
            #     resp = generate_api_scripts(processing_json)
            #     return resp
            #
            # elif processing_json['phase'] == 'GenerateStepDefinition':
            #     resp = generate_stepDef_scripts(processing_json)
            #     return resp
            #
            # elif processing_json['phase'] == 'GenerateJmeterScript':
            #     resp = generate_jmeter_script(processing_json)
            #     return resp
            #
            # elif processing_json['phase'] == 'UserStoryToTestData':
            #     resp = generate_test_data_from_user_story(processing_json)
            #     return resp
            # elif processing_json['phase'] == 'GenerateCypressWebTs':
            #     resp = generate_cypress_web_ts_interface(processing_json)
            #     return resp

        except Exception as e:
            print(str(e))
            # self.loggers.error(traceback.format_exc())
            return {"resultStatus": "ERROR", "resultMessage": str(e)}
