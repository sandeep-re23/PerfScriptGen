import bz2
import os
import shutil
from collections import OrderedDict

import chardet
from gridfs import GridFS
from pymongo import MongoClient

from Constants import DBConstants, PathConstants
from DAOLayer.MongoReadWrite import mongoReadWrite
from datetime import datetime
import time
import pandas as pd
import requests
import random
import mimetypes
# from Src.CoreLogicLayer.IntelligentAutomation.FunctionalTestAutomation.SharedResources.main import ScriptGeneration
from Utilities.FileHandling.EmptyDirectory import EmptyDirectory
from Utilities.FileHandling.FileHandling import create_zip
from pathlib import Path

import CraftRunnerJMX

mongo_obj = mongoReadWrite()


def generate_automation_script(processing_json):
    start = time.time()
    print(processing_json['jobID'])
    execution_details = {'jobID': processing_json['jobID'], 'description': 'Not decided yet',
                         'useCaseName': processing_json['useCaseName'],
                         'generationOption': str(processing_json), 'input': 1, 'output': 'N/A',
                         'executedOn': datetime.now().strftime("%dth %b, %Y %H:%M:%S"), 'timeTaken': 0,
                         'executedBy': processing_json['executedBy'], 'executionStatus': 'Generating',
                         'detailedStatus': [{"title": "Analyzing test case",
                                             "status": "inprogress"}],
                         'projectID': processing_json['projectID']}

    timestamp = execution_details['executedOn'].replace(' ', '').replace(':', '')
    execution_details_df = pd.DataFrame(execution_details, index=[0])
    mongo_obj.write_data('ExecutionSummary', execution_details_df)
    try:

        content = mongo_obj.read_filecontent_from_gridfs(DBConstants.FILES_COLLECTION, processing_json['fileName'])
        CraftRunnerJMX.read_and_categorize_file(content);
        random_id = random.randint(1, 1000)
        upload_file("jmeterapitest.jmx","JmeterJmxFile",random_id,"jmx")
        #
        # # Define the URL for your Java controller
        # url = "http://localhost:8080/userStory/upload"  # Replace with your actual URL
        #
        # # Set the parameters
        # params = {
        #     "projectName": "GenAiJmeterJMX",
        #     "userId": str(random_id),
        #     "type": "txt"
        # }
        #
        # # Read the file (assuming you have a file to upload)
        # with open("jmeterapitest.txt", "rb") as file:
        #     files = {"file": file.read()}  # Read the file contents
        #
        # # Make the POST request
        # response = requests.post(url, params=params, files=files)
        #
        # # Check the response
        # if response.status_code == 200:
        #     print("File uploaded successfully!")
        # else:
        #     print(f"Error: {response.status_code} - {response.text}")

        if not os.path.exists("../dataupload"):
            os.makedirs("../dataupload")

        if processing_json['language'] == "Selenium-Java" and not processing_json['isTestNG']:
            create_zip(f"{PathConstants.SELE_JAVA}/{processing_json['language']}Output",
                       f"../dataupload/GeneratedScripts_{timestamp}.zip")

        if processing_json['language'] == "Selenium-Java" and processing_json['isTestNG']:
            create_zip(f"{PathConstants.SELE_JAVA_TEST_NG}/Output", f"../dataupload/GeneratedScripts_{timestamp}.zip")

        if processing_json['language'] == "Selenium-Python" and not processing_json['isCRAFT']:
            create_zip(f"{PathConstants.SELE_PYTHON}/{processing_json['language']}Output",
                       f"../dataupload/GeneratedScripts_{timestamp}.zip")

        if processing_json['language'] == "Selenium-Python" and processing_json['isCRAFT']:
            create_zip(f"{PathConstants.KARATE_FRAMEWORK}/Output", f"../dataupload/GeneratedScripts_{timestamp}.zip")

        if processing_json['language'] == "Robot-Framework":
            create_zip(f"{PathConstants.ROBOT_FRAMEWORK}/Output", f"../dataupload/GeneratedScripts_{timestamp}.zip")

        if processing_json['language'] == "Playwright-Javascript":
            create_zip(f"{PathConstants.PLAYWRIGHT_JAVASCRIPT}/Output",
                       f"../dataupload/GeneratedScripts_{timestamp}.zip")

        mongo_obj.store_zip_in_mongodb(DBConstants.SCRIPTS_COLLECTION,
                                       f"../dataupload/GeneratedScripts_{timestamp}.zip", execution_details['jobID'])

        # if processing_json['language'] == "Selenium-Java":
        #     shutil.copytree("../CoreLogicLayer/IntelligentAutomation/FunctionalTestAutomation/SeleniumJava/data/craft/com",
        #                     f"../CoreLogicLayer/IntelligentAutomation/FunctionalTestAutomation/SeleniumJava/{processing_json['language']}Output/com",
        #                     dirs_exist_ok=True)

        # create_zip(f"../CoreLogicLayer/IntelligentAutomation/FunctionalTestAutomation/SeleniumJava/{processing_json['language']}Output", f"../dataupload/GeneratedScripts_{timestamp}.zip")

        # Clean up: remove the temporary ZIP file
        os.remove(f"../dataupload/GeneratedScripts_{timestamp}.zip")
        # remover = EmptyDirectory()
        # if processing_json['language'] == "Selenium-Java":
        #     remover.remove(f"{PathConstants.SELE_JAVA}/{processing_json['language']}Output")
        #     remover.remove(f"{PathConstants.SELE_JAVA}/data/FrameworkScripts")
        # if processing_json['language'] == "Selenium-Python":
        #     remover.remove(f"{PathConstants.SELE_PYTHON}/{processing_json['language']}Output")

        mongo_obj.update_field_based_on_jobid('ExecutionSummary', execution_details['jobID'], 'output', 1)
        mongo_obj.update_field_based_on_jobid('ExecutionSummary', execution_details['jobID'], 'executionStatus',
                                              'Completed')
        mongo_obj.update_field_based_on_jobid('ExecutionSummary', execution_details['jobID'], 'detailedStatus',
                                              [{"title": "Analyzing test case",
                                                "status": "completed"},
                                               {"title": "Gathering script context",
                                                "status": "completed"},
                                               {"title": "Determining reusability scope",
                                                "status": "completed"},
                                               {"title": "Prompt engineering with dynamic context",
                                                "status": "completed"},
                                               {"title": "Generating Automation scripts",
                                                "status": "completed"}]
                                              )

        return {"message": "Script generated successfully"}
    except Exception as e:
        mongo_obj.update_field_based_on_jobid('ExecutionSummary', execution_details['jobID'], 'timeTaken',
                                              (time.time() - start).__round__())
        mongo_obj.update_field_based_on_jobid('ExecutionSummary', execution_details['jobID'], 'executionStatus',
                                              'Failed')
        mongo_obj.update_status_failure_based_on_jobid('ExecutionSummary', execution_details['jobID'], 'detailedStatus',
                                                       'status',
                                                       'failed')
        print(e)
        return {"message": "Script generation failed"}

def upload_file(file_path, project_name, user_id, file_type):
    try:
        source_path = "jmeterapitest.jmx"
        destination_path = "../Output/jmeterapitest.jmx"

        shutil.copyfile(source_path, destination_path)


        client = MongoClient("mongodb://10.120.101.34/")
        db = client["neuro_dev"]
        collection_name = "Scripts"
        fs = GridFS(db, collection=collection_name)
        # Get file extension
        file_extension = os.path.splitext(file_path)[1]
        filename = f"{file_type}_{project_name}_{user_id}{file_extension}"

        # Read file content
        with open(file_path, "rb") as file:
            file_content = file.read()

        # Save file locally

        # db[collection_name].insert_one({filename: file_content})
        fs.put(file_content, filename=filename)

        print(f"File uploaded to collection '{collection_name}' successfully.")




        # local_path = Path(filename)
        # with open(local_path, "wb") as local_file:
        #     local_file.write(file_content)
        #
        # # Prepare the URL for file upload
        # upload_url = "http://10.120.101.34:8000/uploadfile"
        #
        #
        #
        # # Create a dictionary for the file
        # files = {"file": (filename, file_content)}
        #
        # # Send the HTTP POST request
        # response = requests.post(upload_url, files=files)
        #
        # # Handle the response
        # if response.status_code == 200:
        #     json_response = response.json()
        #     print("Response:", json_response)
        # else:
        #     print("Error:", response.status_code, response.text)
        #
        # # Clean up: Delete the local file
        # local_path.unlink()

    except Exception as e:
        print("Error:", str(e))