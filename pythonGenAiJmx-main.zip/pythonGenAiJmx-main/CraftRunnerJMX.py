from SwaggerPreprocessing import read_feature_file, read_jmx
from CraftAzureConnectJMX import CraftAsureConnectJMX
import re
 
 
def read_and_categorize_file(content):
    # with open('..\Input\genAIinput.feature','w') as f:
    #     f.write(content)

    contentFinal = content.decode('utf-8')
    example_feature_file_path = r"..\Input\customer_service-Copy.feature"
    # example_json1 = r"Input\Register_user.json"
    # example_json2 = r"Input\user_name.json"
    # example_json3 = r"Input\newProduct.json"
    example_feature_file, scenarios = read_feature_file(example_feature_file_path,[])

    jmx = r"..\Input\SwaggerFinal.jmx"
    jmx_file = read_jmx(jmx)
 
    # feature_file_path = r"Input\customer_service.feature"
    # json1 = r"Input\Register_user.json"
    # json2 = r"Input\user_name.json"
    # json3 = r"Input\newProduct.json"
    # feature_file, scenarios1 = read_feature_file(feature_file_path, [json1,json2,json3])

    feature_file_path = r"..\Input\genAIinput.feature"
    # json1 = r"Input\pet_Register_user.json"
    # json2 = r"Input\petProduct.json"
    # json3 = r"Input\pet_Register_user.json"
    feature_file, scenarios1 = read_feature_file(feature_file_path,[])
    feature_file = contentFinal
    feature_string = contentFinal
    post_pattern = re.compile(r'\bPOST\b')
    get_pattern = re.compile(r'\bGET\b')
    post_matches = post_pattern.findall(feature_string)
    get_matches = get_pattern.findall(feature_string)
    post_count = len(post_matches)
    get_count = len(get_matches)
    total_count_feature = post_count + get_count
    print(total_count_feature)
    print(feature_file)
    jmx_output = CraftAsureConnectJMX.code_generation(CraftAsureConnectJMX, example_feature_file, jmx_file,
                                                           feature_file)
    jmx_file_output = CraftAsureConnectJMX.complete_jmx(jmx_output)
 
    get_pattern_jmx = re.compile(r'>GET<')
    post_pattern_jmx = re.compile(r'>POST<')
    get_matches_jmx = get_pattern_jmx.findall(jmx_file_output)
    post_matches_jmx = post_pattern_jmx.findall(jmx_file_output)
    total_count_jmx = len(get_matches_jmx) + len(post_matches_jmx)

    print(total_count_jmx)
 
    while not (total_count_feature == total_count_jmx):
        jmx_file_output = CraftAsureConnectJMX.code_generation_iterative(CraftAsureConnectJMX, example_feature_file,
                                                                         jmx_file,
                                                                         feature_file, jmx_file_output)
        get_matches_jmx = get_pattern_jmx.findall(jmx_file_output)
        post_matches_jmx = post_pattern_jmx.findall(jmx_file_output)
        total_count_jmx = len(get_matches_jmx) + len(post_matches_jmx)
        print(total_count_feature)
        print(total_count_jmx)
 
 
# if __name__ == "__main__":
#     content = b'Feature: PetStore \n\n\tScenario 1 : (Store Order)\n\n\t\tPOST\n\t\tuse JSON extractor to extract "orderId","quantity","status",\n\t\tmake a GET request to the endpoint <get_endpoint>+"orderId"   \n\t\tGET\n\n\t\t\t| payload_file | post_endpoint | post_status_code | get_endpoint | get_status_code|\n\t\t\t| {"petId":"0","quantity":"0","id":"0","shipDate":"2024-06-06T12:19:03.223748","complete":"true","status":"placed"} | "/store/order" | "200" | "/store/order" | "200"|\n\t\t\t|  |  |  | "/store/inventory" | "200"|\n\n\n\tScenario 2  : (Store Order)\n\n\t\tPOST\n\t\tuse JSON extractor to extract "orderId","quantity","status",\n\t\tmake a GET request to the endpoint <get_endpoint>+"orderId"   \n\n\t\t\t| payload_file | post_endpoint | post_status_code | get_endpoint | get_status_code|\n\t\t\t| {"petId":"0","quantity":"0","id":"0","shipDate":"2024-06-06T12:19:03.284046200","complete":"true","status":"placed"} | "/store/order" | "200" | "/store/order" | "200"|\n'
#     read_and_categorize_file(content)